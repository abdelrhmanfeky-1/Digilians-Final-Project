/*
===============================================================================
 Electronics Manufacturing & Supply Chain Database - FINAL 200K DATA VERSION
 SQL Server / SSMS
===============================================================================

Purpose
-------
This DDL is aligned with the FINAL 31-table Python generator and its CSV files
(200,000 business rows in total).

Important design choices for CSV loading
----------------------------------------
1) Primary keys are INT but NOT IDENTITY because the CSV files already contain
   the exact IDs used by all foreign keys. This makes loading the generated CSVs
   much easier and preserves end-to-end traceability.
2) The script is rerunnable. It drops the 31 business tables in reverse FK order
   and recreates them. Re-running it DELETES all previously loaded data.
3) No extra physical columns were added. Table columns match the CSV headers.
4) The intentional data-cleaning issues are allowed by the schema. For example:
   - Customers.email can be NULL.
   - customer_type / supplier city / material_category are not restricted by
     strict categorical CHECK constraints because the dataset intentionally
     contains small case/spacing inconsistencies for cleaning practice.
5) Operational business problems are also allowed by design. For example:
   RawMaterialInventory can be above max_inventory_level because controlled
   overstock records are intentionally present for analysis.

Recommended CSV load order
--------------------------
01 Departments
02 Materials
03 Suppliers
04 SupplierMaterials
05 PurchaseRequisitions
06 PurchaseRequisitionDetails
07 PurchaseOrders
08 PurchaseOrderDetails
09 SupplierShipments
10 SupplierShipmentDetails
11 GoodsReceipts
12 GoodsReceiptDetails
13 QualityInspections
14 SupplierInvoices
15 SupplierInvoiceDetails
16 SupplierPayments
17 Warehouses
18 RawMaterialInventory
19 Products
20 ProductBOM
21 Production
22 ProductionDetails
23 RawMaterialInventoryTransactions
24 FinishedGoodsInventory
25 Customers
26 SalesOrders
27 SalesOrderDetails
28 CustomerShipments
29 CustomerShipmentDetails
30 FinishedGoodsInventoryTransactions
31 Returns
===============================================================================
*/

USE master;
GO

IF DB_ID(N'ElectronicsSupplyChainDB') IS NULL
BEGIN
    CREATE DATABASE ElectronicsSupplyChainDB;
END;
GO

USE ElectronicsSupplyChainDB;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*=============================================================================
 1. SCHEMAS
=============================================================================*/
IF SCHEMA_ID(N'procurement') IS NULL
    EXEC(N'CREATE SCHEMA procurement AUTHORIZATION dbo;');
GO
IF SCHEMA_ID(N'inbound') IS NULL
    EXEC(N'CREATE SCHEMA inbound AUTHORIZATION dbo;');
GO
IF SCHEMA_ID(N'inventory') IS NULL
    EXEC(N'CREATE SCHEMA inventory AUTHORIZATION dbo;');
GO
IF SCHEMA_ID(N'production') IS NULL
    EXEC(N'CREATE SCHEMA production AUTHORIZATION dbo;');
GO
IF SCHEMA_ID(N'sales') IS NULL
    EXEC(N'CREATE SCHEMA sales AUTHORIZATION dbo;');
GO
IF SCHEMA_ID(N'returns_data') IS NULL
    EXEC(N'CREATE SCHEMA returns_data AUTHORIZATION dbo;');
GO

/*=============================================================================
 2. DROP TABLES IN REVERSE DEPENDENCY ORDER
=============================================================================*/
DROP TABLE IF EXISTS returns_data.Returns;
DROP TABLE IF EXISTS sales.FinishedGoodsInventoryTransactions;
DROP TABLE IF EXISTS sales.CustomerShipmentDetails;
DROP TABLE IF EXISTS sales.CustomerShipments;
DROP TABLE IF EXISTS sales.SalesOrderDetails;
DROP TABLE IF EXISTS sales.SalesOrders;
DROP TABLE IF EXISTS sales.Customers;
DROP TABLE IF EXISTS sales.FinishedGoodsInventory;

DROP TABLE IF EXISTS inventory.RawMaterialInventoryTransactions;
DROP TABLE IF EXISTS production.ProductionDetails;
DROP TABLE IF EXISTS production.Production;
DROP TABLE IF EXISTS production.ProductBOM;
DROP TABLE IF EXISTS production.Products;
DROP TABLE IF EXISTS inventory.RawMaterialInventory;
DROP TABLE IF EXISTS inventory.Warehouses;

DROP TABLE IF EXISTS inbound.SupplierPayments;
DROP TABLE IF EXISTS inbound.SupplierInvoiceDetails;
DROP TABLE IF EXISTS inbound.SupplierInvoices;
DROP TABLE IF EXISTS inbound.QualityInspections;
DROP TABLE IF EXISTS inbound.GoodsReceiptDetails;
DROP TABLE IF EXISTS inbound.GoodsReceipts;
DROP TABLE IF EXISTS inbound.SupplierShipmentDetails;
DROP TABLE IF EXISTS inbound.SupplierShipments;

DROP TABLE IF EXISTS procurement.PurchaseOrderDetails;
DROP TABLE IF EXISTS procurement.PurchaseOrders;
DROP TABLE IF EXISTS procurement.PurchaseRequisitionDetails;
DROP TABLE IF EXISTS procurement.PurchaseRequisitions;
DROP TABLE IF EXISTS procurement.SupplierMaterials;
DROP TABLE IF EXISTS procurement.Suppliers;
DROP TABLE IF EXISTS procurement.Materials;
DROP TABLE IF EXISTS procurement.Departments;
GO

/*=============================================================================
 3. PROCUREMENT & SOURCING
=============================================================================*/
CREATE TABLE procurement.Departments
(
    department_id          INT          NOT NULL,
    department_code        VARCHAR(20)  NOT NULL,
    department_name        VARCHAR(100) NOT NULL,
    department_description VARCHAR(250) NOT NULL,
    status                 VARCHAR(20)  NOT NULL,

    CONSTRAINT PK_Departments PRIMARY KEY (department_id),
    CONSTRAINT UQ_Departments_Code UNIQUE (department_code)
);
GO

CREATE TABLE procurement.Materials
(
    material_id       INT           NOT NULL,
    material_code     VARCHAR(30)   NOT NULL,
    material_name     VARCHAR(100)  NOT NULL,
    material_category VARCHAR(60)   NOT NULL,
    material_type     VARCHAR(50)   NOT NULL,
    uom               VARCHAR(20)   NOT NULL,
    unit_weight       DECIMAL(18,3) NOT NULL,
    status            VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_Materials PRIMARY KEY (material_id),
    CONSTRAINT UQ_Materials_Code UNIQUE (material_code),
    CONSTRAINT CK_Materials_UnitWeight CHECK (unit_weight >= 0)
);
GO

CREATE TABLE procurement.Suppliers
(
    supplier_id       INT          NOT NULL,
    supplier_code     VARCHAR(30)  NOT NULL,
    supplier_name     VARCHAR(120) NOT NULL,
    supplier_type     VARCHAR(50)  NOT NULL,
    supplier_category VARCHAR(50)  NOT NULL,
    country           VARCHAR(50)  NOT NULL,
    city              VARCHAR(50)  NOT NULL,
    address           VARCHAR(250) NOT NULL,
    contact_person    VARCHAR(100) NOT NULL,
    phone             VARCHAR(20)  NOT NULL,
    email             VARCHAR(120) NOT NULL,
    payment_terms     VARCHAR(50)  NOT NULL,
    status            VARCHAR(20)  NOT NULL,

    CONSTRAINT PK_Suppliers PRIMARY KEY (supplier_id),
    CONSTRAINT UQ_Suppliers_Code UNIQUE (supplier_code)
);
GO

CREATE TABLE procurement.SupplierMaterials
(
    supplier_material_id   INT           NOT NULL,
    supplier_id            INT           NOT NULL,
    material_id            INT           NOT NULL,
    supplier_material_code VARCHAR(50)   NOT NULL,
    standard_price         DECIMAL(18,2) NOT NULL,
    lead_time_days         INT           NOT NULL,
    minimum_order_quantity DECIMAL(18,2) NOT NULL,
    preferred_supplier     BIT           NOT NULL,
    status                 VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_SupplierMaterials PRIMARY KEY (supplier_material_id),
    CONSTRAINT UQ_SupplierMaterials UNIQUE (supplier_id, material_id),
    CONSTRAINT FK_SupplierMaterials_Suppliers
        FOREIGN KEY (supplier_id) REFERENCES procurement.Suppliers(supplier_id),
    CONSTRAINT FK_SupplierMaterials_Materials
        FOREIGN KEY (material_id) REFERENCES procurement.Materials(material_id),
    CONSTRAINT CK_SupplierMaterials_Price CHECK (standard_price >= 0),
    CONSTRAINT CK_SupplierMaterials_LeadTime CHECK (lead_time_days >= 0),
    CONSTRAINT CK_SupplierMaterials_MinQty CHECK (minimum_order_quantity > 0)
);
GO

CREATE TABLE procurement.PurchaseRequisitions
(
    pr_id            INT          NOT NULL,
    pr_code          VARCHAR(20)  NOT NULL,
    department_id    INT          NOT NULL,
    requested_by     VARCHAR(100) NOT NULL,
    request_date     DATE         NOT NULL,
    order_date       DATE         NULL,  -- NULL for rejected PRs
    required_date    DATE         NOT NULL,
    priority         VARCHAR(20)  NOT NULL,
    approval_status  VARCHAR(20)  NOT NULL,
    approved_by      VARCHAR(100) NOT NULL,
    approval_date    DATE         NOT NULL,
    rejection_reason VARCHAR(250) NULL,  -- NULL for approved PRs
    created_date     DATETIME2(0) NOT NULL,

    CONSTRAINT PK_PurchaseRequisitions PRIMARY KEY (pr_id),
    CONSTRAINT UQ_PurchaseRequisitions_Code UNIQUE (pr_code),
    CONSTRAINT FK_PurchaseRequisitions_Departments
        FOREIGN KEY (department_id) REFERENCES procurement.Departments(department_id),
    CONSTRAINT CK_PR_Dates CHECK (required_date >= request_date),
    CONSTRAINT CK_PR_ApprovalDate CHECK (approval_date >= request_date)
);
GO

CREATE TABLE procurement.PurchaseRequisitionDetails
(
    pr_detail_id        INT           NOT NULL,
    pr_id               INT           NOT NULL,
    material_id         INT           NOT NULL,
    requested_quantity  DECIMAL(18,2) NOT NULL,
    estimated_unit_cost DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_PurchaseRequisitionDetails PRIMARY KEY (pr_detail_id),
    CONSTRAINT UQ_PRDetails_Line UNIQUE (pr_id, material_id),
    CONSTRAINT FK_PRDetails_PR
        FOREIGN KEY (pr_id) REFERENCES procurement.PurchaseRequisitions(pr_id),
    CONSTRAINT FK_PRDetails_Materials
        FOREIGN KEY (material_id) REFERENCES procurement.Materials(material_id),
    CONSTRAINT CK_PRDetails_Quantity CHECK (requested_quantity > 0),
    CONSTRAINT CK_PRDetails_Cost CHECK (estimated_unit_cost >= 0)
);
GO

CREATE TABLE procurement.PurchaseOrders
(
    po_id                  INT          NOT NULL,
    po_code                VARCHAR(20)  NOT NULL,
    supplier_id            INT          NOT NULL,
    pr_id                  INT          NOT NULL,
    order_date             DATE         NOT NULL,
    expected_delivery_date DATE         NOT NULL,
    payment_terms          VARCHAR(50)  NOT NULL,
    status                 VARCHAR(20)  NOT NULL,

    CONSTRAINT PK_PurchaseOrders PRIMARY KEY (po_id),
    CONSTRAINT UQ_PurchaseOrders_Code UNIQUE (po_code),
    CONSTRAINT UQ_PurchaseOrders_PR UNIQUE (pr_id),
    CONSTRAINT FK_PurchaseOrders_Suppliers
        FOREIGN KEY (supplier_id) REFERENCES procurement.Suppliers(supplier_id),
    CONSTRAINT FK_PurchaseOrders_PR
        FOREIGN KEY (pr_id) REFERENCES procurement.PurchaseRequisitions(pr_id),
    CONSTRAINT CK_PurchaseOrders_Dates CHECK (expected_delivery_date >= order_date)
);
GO

CREATE TABLE procurement.PurchaseOrderDetails
(
    po_detail_id           INT           NOT NULL,
    po_id                  INT           NOT NULL,
    pr_detail_id           INT           NOT NULL,
    material_id            INT           NOT NULL,
    ordered_quantity       DECIMAL(18,2) NOT NULL,
    unit_price             DECIMAL(18,2) NOT NULL,
    discount_percentage    DECIMAL(5,2)  NOT NULL,
    expected_delivery_date DATE          NOT NULL,
    total_amount           DECIMAL(18,2) NOT NULL,
    line_status            VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_PurchaseOrderDetails PRIMARY KEY (po_detail_id),
    CONSTRAINT UQ_PODetails_PRLine UNIQUE (po_id, pr_detail_id),
    CONSTRAINT FK_PODetails_PO
        FOREIGN KEY (po_id) REFERENCES procurement.PurchaseOrders(po_id),
    CONSTRAINT FK_PODetails_PRDetails
        FOREIGN KEY (pr_detail_id) REFERENCES procurement.PurchaseRequisitionDetails(pr_detail_id),
    CONSTRAINT FK_PODetails_Materials
        FOREIGN KEY (material_id) REFERENCES procurement.Materials(material_id),
    CONSTRAINT CK_PODetails_Quantity CHECK (ordered_quantity > 0),
    CONSTRAINT CK_PODetails_UnitPrice CHECK (unit_price >= 0),
    CONSTRAINT CK_PODetails_Discount CHECK (discount_percentage BETWEEN 0 AND 100),
    CONSTRAINT CK_PODetails_Total CHECK (total_amount >= 0)
);
GO

/*=============================================================================
 4. INBOUND LOGISTICS, RECEIVING & ACCOUNTS PAYABLE
=============================================================================*/
CREATE TABLE inbound.SupplierShipments
(
    shipment_id           INT           NOT NULL,
    shipment_code         VARCHAR(20)   NOT NULL,
    po_id                 INT           NOT NULL,
    supplier_id           INT           NOT NULL,
    supplier_reference    VARCHAR(50)   NOT NULL,
    ship_date             DATE          NOT NULL,
    expected_arrival_date DATE          NOT NULL,
    actual_arrival_date   DATE          NOT NULL,
    total_shipment_value  DECIMAL(18,2) NOT NULL,
    shipping_cost         DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_SupplierShipments PRIMARY KEY (shipment_id),
    CONSTRAINT UQ_SupplierShipments_Code UNIQUE (shipment_code),
    CONSTRAINT FK_SupplierShipments_PO
        FOREIGN KEY (po_id) REFERENCES procurement.PurchaseOrders(po_id),
    CONSTRAINT FK_SupplierShipments_Suppliers
        FOREIGN KEY (supplier_id) REFERENCES procurement.Suppliers(supplier_id),
    CONSTRAINT CK_SupplierShipments_Dates
        CHECK (expected_arrival_date >= ship_date AND actual_arrival_date >= ship_date),
    CONSTRAINT CK_SupplierShipments_Value CHECK (total_shipment_value >= 0),
    CONSTRAINT CK_SupplierShipments_Cost CHECK (shipping_cost >= 0)
);
GO

CREATE TABLE inbound.SupplierShipmentDetails
(
    shipment_detail_id INT           NOT NULL,
    shipment_id        INT           NOT NULL,
    po_detail_id       INT           NOT NULL,
    material_id        INT           NOT NULL,
    received_quantity  DECIMAL(18,2) NOT NULL,
    accepted_quantity  DECIMAL(18,2) NOT NULL,
    rejected_quantity  DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_SupplierShipmentDetails PRIMARY KEY (shipment_detail_id),
    CONSTRAINT UQ_SupplierShipmentDetails_Line UNIQUE (shipment_id, po_detail_id),
    CONSTRAINT FK_SupplierShipmentDetails_Shipments
        FOREIGN KEY (shipment_id) REFERENCES inbound.SupplierShipments(shipment_id),
    CONSTRAINT FK_SupplierShipmentDetails_PODetails
        FOREIGN KEY (po_detail_id) REFERENCES procurement.PurchaseOrderDetails(po_detail_id),
    CONSTRAINT FK_SupplierShipmentDetails_Materials
        FOREIGN KEY (material_id) REFERENCES procurement.Materials(material_id),
    CONSTRAINT CK_SupplierShipmentDetails_Received CHECK (received_quantity > 0),
    CONSTRAINT CK_SupplierShipmentDetails_Accepted CHECK (accepted_quantity >= 0),
    CONSTRAINT CK_SupplierShipmentDetails_Rejected CHECK (rejected_quantity >= 0),
    CONSTRAINT CK_SupplierShipmentDetails_Balance
        CHECK (accepted_quantity + rejected_quantity = received_quantity)
);
GO

CREATE TABLE inbound.GoodsReceipts
(
    gr_id                INT           NOT NULL,
    gr_code              VARCHAR(20)   NOT NULL,
    shipment_id          INT           NOT NULL,
    receipt_date         DATE          NOT NULL,
    received_by          VARCHAR(100)  NOT NULL,
    quality_check_status VARCHAR(20)   NOT NULL,
    total_received_value DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_GoodsReceipts PRIMARY KEY (gr_id),
    CONSTRAINT UQ_GoodsReceipts_Code UNIQUE (gr_code),
    CONSTRAINT UQ_GoodsReceipts_Shipment UNIQUE (shipment_id),
    CONSTRAINT FK_GoodsReceipts_Shipments
        FOREIGN KEY (shipment_id) REFERENCES inbound.SupplierShipments(shipment_id),
    CONSTRAINT CK_GoodsReceipts_Value CHECK (total_received_value >= 0)
);
GO

CREATE TABLE inbound.GoodsReceiptDetails
(
    gr_detail_id       INT           NOT NULL,
    gr_id              INT           NOT NULL,
    shipment_detail_id INT           NOT NULL,
    material_id        INT           NOT NULL,
    received_quantity  DECIMAL(18,2) NOT NULL,
    accepted_quantity  DECIMAL(18,2) NOT NULL,
    rejected_quantity  DECIMAL(18,2) NOT NULL,
    inspection_status  VARCHAR(30)   NOT NULL,
    batch_number       VARCHAR(50)   NOT NULL,

    CONSTRAINT PK_GoodsReceiptDetails PRIMARY KEY (gr_detail_id),
    CONSTRAINT UQ_GoodsReceiptDetails_ShipmentLine UNIQUE (shipment_detail_id),
    CONSTRAINT UQ_GoodsReceiptDetails_Batch UNIQUE (batch_number),
    CONSTRAINT FK_GoodsReceiptDetails_GR
        FOREIGN KEY (gr_id) REFERENCES inbound.GoodsReceipts(gr_id),
    CONSTRAINT FK_GoodsReceiptDetails_ShipmentDetails
        FOREIGN KEY (shipment_detail_id)
        REFERENCES inbound.SupplierShipmentDetails(shipment_detail_id),
    CONSTRAINT FK_GoodsReceiptDetails_Materials
        FOREIGN KEY (material_id) REFERENCES procurement.Materials(material_id),
    CONSTRAINT CK_GoodsReceiptDetails_Received CHECK (received_quantity > 0),
    CONSTRAINT CK_GoodsReceiptDetails_Accepted CHECK (accepted_quantity >= 0),
    CONSTRAINT CK_GoodsReceiptDetails_Rejected CHECK (rejected_quantity >= 0),
    CONSTRAINT CK_GoodsReceiptDetails_Balance
        CHECK (accepted_quantity + rejected_quantity = received_quantity)
);
GO

CREATE TABLE inbound.QualityInspections
(
    inspection_id         INT           NOT NULL,
    gr_detail_id          INT           NOT NULL,
    inspection_date       DATE          NOT NULL,
    inspection_type       VARCHAR(50)   NOT NULL,
    inspected_quantity    DECIMAL(18,2) NOT NULL,
    passed_quantity       DECIMAL(18,2) NOT NULL,
    inspection_result     VARCHAR(30)   NOT NULL,
    defect_quantity       DECIMAL(18,2) NOT NULL,
    defect_reason         VARCHAR(250)  NOT NULL,
    corrective_action     VARCHAR(250)  NOT NULL,
    reinspection_required BIT           NOT NULL,
    status                VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_QualityInspections PRIMARY KEY (inspection_id),
    CONSTRAINT UQ_QualityInspections_GRDetail UNIQUE (gr_detail_id),
    CONSTRAINT FK_QualityInspections_GRDetails
        FOREIGN KEY (gr_detail_id) REFERENCES inbound.GoodsReceiptDetails(gr_detail_id),
    CONSTRAINT CK_QualityInspections_Inspected CHECK (inspected_quantity > 0),
    CONSTRAINT CK_QualityInspections_Passed CHECK (passed_quantity >= 0),
    CONSTRAINT CK_QualityInspections_Defect CHECK (defect_quantity >= 0),
    CONSTRAINT CK_QualityInspections_Balance
        CHECK (passed_quantity + defect_quantity = inspected_quantity)
);
GO

CREATE TABLE inbound.SupplierInvoices
(
    invoice_id     INT           NOT NULL,
    invoice_number VARCHAR(30)   NOT NULL,
    shipment_id    INT           NOT NULL,
    supplier_id    INT           NOT NULL,
    invoice_date   DATE          NOT NULL,
    invoice_amount DECIMAL(18,2) NOT NULL,
    tax_amount     DECIMAL(18,2) NOT NULL,
    total_amount   DECIMAL(18,2) NOT NULL,
    due_date       DATE          NOT NULL,
    payment_terms  VARCHAR(50)   NOT NULL,
    payment_status VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_SupplierInvoices PRIMARY KEY (invoice_id),
    CONSTRAINT UQ_SupplierInvoices_Number UNIQUE (invoice_number),
    CONSTRAINT UQ_SupplierInvoices_Shipment UNIQUE (shipment_id),
    CONSTRAINT FK_SupplierInvoices_Shipments
        FOREIGN KEY (shipment_id) REFERENCES inbound.SupplierShipments(shipment_id),
    CONSTRAINT FK_SupplierInvoices_Suppliers
        FOREIGN KEY (supplier_id) REFERENCES procurement.Suppliers(supplier_id),
    CONSTRAINT CK_SupplierInvoices_Amounts
        CHECK (invoice_amount >= 0 AND tax_amount >= 0 AND total_amount >= 0),
    CONSTRAINT CK_SupplierInvoices_Total
        CHECK (ABS(total_amount - (invoice_amount + tax_amount)) <= 0.05),
    CONSTRAINT CK_SupplierInvoices_Dates CHECK (due_date >= invoice_date)
);
GO

CREATE TABLE inbound.SupplierInvoiceDetails
(
    invoice_detail_id INT           NOT NULL,
    invoice_id        INT           NOT NULL,
    gr_detail_id      INT           NOT NULL,
    billed_quantity   DECIMAL(18,2) NOT NULL,
    unit_price        DECIMAL(18,2) NOT NULL,
    tax_amount        DECIMAL(18,2) NOT NULL,
    line_amount       DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_SupplierInvoiceDetails PRIMARY KEY (invoice_detail_id),
    CONSTRAINT UQ_SupplierInvoiceDetails_Line UNIQUE (invoice_id, gr_detail_id),
    CONSTRAINT FK_SupplierInvoiceDetails_Invoices
        FOREIGN KEY (invoice_id) REFERENCES inbound.SupplierInvoices(invoice_id),
    CONSTRAINT FK_SupplierInvoiceDetails_GRDetails
        FOREIGN KEY (gr_detail_id) REFERENCES inbound.GoodsReceiptDetails(gr_detail_id),
    CONSTRAINT CK_SupplierInvoiceDetails_Quantity CHECK (billed_quantity > 0),
    CONSTRAINT CK_SupplierInvoiceDetails_Amounts
        CHECK (unit_price >= 0 AND tax_amount >= 0 AND line_amount >= 0)
);
GO

CREATE TABLE inbound.SupplierPayments
(
    payment_id            INT           NOT NULL,
    invoice_id            INT           NOT NULL,
    payment_date          DATE          NOT NULL,
    payment_amount        DECIMAL(18,2) NOT NULL,
    payment_method        VARCHAR(30)   NOT NULL,
    currency              CHAR(3)       NOT NULL,
    transaction_reference VARCHAR(100)  NOT NULL,
    payment_status        VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_SupplierPayments PRIMARY KEY (payment_id),
    CONSTRAINT UQ_SupplierPayments_Reference UNIQUE (transaction_reference),
    CONSTRAINT FK_SupplierPayments_Invoices
        FOREIGN KEY (invoice_id) REFERENCES inbound.SupplierInvoices(invoice_id),
    CONSTRAINT CK_SupplierPayments_Amount CHECK (payment_amount > 0)
);
GO

/*=============================================================================
 5. WAREHOUSES & RAW MATERIAL INVENTORY
=============================================================================*/
CREATE TABLE inventory.Warehouses
(
    warehouse_id         INT          NOT NULL,
    warehouse_code       VARCHAR(20)  NOT NULL,
    warehouse_name       VARCHAR(100) NOT NULL,
    warehouse_type       VARCHAR(50)  NOT NULL,
    country              VARCHAR(50)  NOT NULL,
    city                 VARCHAR(50)  NOT NULL,
    location_description VARCHAR(250) NOT NULL,
    status               VARCHAR(20)  NOT NULL,

    CONSTRAINT PK_Warehouses PRIMARY KEY (warehouse_id),
    CONSTRAINT UQ_Warehouses_Code UNIQUE (warehouse_code)
);
GO

CREATE TABLE inventory.RawMaterialInventory
(
    raw_inventory_id    INT           NOT NULL,
    warehouse_id        INT           NOT NULL,
    material_id         INT           NOT NULL,
    quantity_on_hand    DECIMAL(18,2) NOT NULL,
    quantity_reserved   DECIMAL(18,2) NOT NULL,
    reorder_point       DECIMAL(18,2) NOT NULL,
    safety_stock_level  DECIMAL(18,2) NOT NULL,
    max_inventory_level DECIMAL(18,2) NOT NULL,
    unit_cost           DECIMAL(18,2) NOT NULL,
    last_updated_at     DATETIME2(0)  NOT NULL,

    CONSTRAINT PK_RawMaterialInventory PRIMARY KEY (raw_inventory_id),
    CONSTRAINT UQ_RawMaterialInventory UNIQUE (warehouse_id, material_id),
    CONSTRAINT FK_RawInventory_Warehouses
        FOREIGN KEY (warehouse_id) REFERENCES inventory.Warehouses(warehouse_id),
    CONSTRAINT FK_RawInventory_Materials
        FOREIGN KEY (material_id) REFERENCES procurement.Materials(material_id),
    CONSTRAINT CK_RawInventory_Quantities
        CHECK (quantity_on_hand >= 0 AND quantity_reserved >= 0 AND quantity_reserved <= quantity_on_hand),
    CONSTRAINT CK_RawInventory_Levels
        CHECK (
            safety_stock_level >= 0
            AND reorder_point >= safety_stock_level
            AND max_inventory_level >= reorder_point
        ),
    CONSTRAINT CK_RawInventory_Cost CHECK (unit_cost >= 0)
    -- Important: quantity_on_hand is intentionally NOT constrained <= max_inventory_level.
    -- The final dataset contains controlled overstock cases for analysis.
);
GO

/*=============================================================================
 6. PRODUCTION / ASSEMBLY
=============================================================================*/
CREATE TABLE production.Products
(
    product_id       INT           NOT NULL,
    product_code     VARCHAR(30)   NOT NULL,
    product_name     VARCHAR(100)  NOT NULL,
    product_category VARCHAR(50)   NOT NULL,
    uom              VARCHAR(20)   NOT NULL,
    standard_cost    DECIMAL(18,2) NOT NULL,
    selling_price    DECIMAL(18,2) NOT NULL,
    status           VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_Products PRIMARY KEY (product_id),
    CONSTRAINT UQ_Products_Code UNIQUE (product_code),
    CONSTRAINT CK_Products_Cost CHECK (standard_cost >= 0),
    CONSTRAINT CK_Products_Price CHECK (selling_price >= 0)
);
GO

CREATE TABLE production.ProductBOM
(
    bom_id            INT           NOT NULL,
    product_id        INT           NOT NULL,
    material_id       INT           NOT NULL,
    quantity_required DECIMAL(18,3) NOT NULL,
    uom               VARCHAR(20)   NOT NULL,
    status            VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_ProductBOM PRIMARY KEY (bom_id),
    CONSTRAINT UQ_ProductBOM UNIQUE (product_id, material_id),
    CONSTRAINT FK_ProductBOM_Products
        FOREIGN KEY (product_id) REFERENCES production.Products(product_id),
    CONSTRAINT FK_ProductBOM_Materials
        FOREIGN KEY (material_id) REFERENCES procurement.Materials(material_id),
    CONSTRAINT CK_ProductBOM_Quantity CHECK (quantity_required > 0)
);
GO

CREATE TABLE production.Production
(
    production_id         INT           NOT NULL,
    production_order_code VARCHAR(30)   NOT NULL,
    product_id            INT           NOT NULL,
    planned_quantity      DECIMAL(18,2) NOT NULL,
    start_date            DATE          NOT NULL,
    expected_end_date     DATE          NOT NULL,
    actual_end_date       DATE          NOT NULL,
    production_quantity   DECIMAL(18,2) NOT NULL,
    rejected_quantity     DECIMAL(18,2) NOT NULL,
    production_status     VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_Production PRIMARY KEY (production_id),
    CONSTRAINT UQ_Production_OrderCode UNIQUE (production_order_code),
    CONSTRAINT FK_Production_Products
        FOREIGN KEY (product_id) REFERENCES production.Products(product_id),
    CONSTRAINT CK_Production_Planned CHECK (planned_quantity > 0),
    CONSTRAINT CK_Production_Produced CHECK (production_quantity > 0),
    CONSTRAINT CK_Production_Rejected CHECK (rejected_quantity >= 0 AND rejected_quantity <= production_quantity),
    CONSTRAINT CK_Production_Dates
        CHECK (expected_end_date >= start_date AND actual_end_date >= start_date)
);
GO

CREATE TABLE production.ProductionDetails
(
    production_detail_id     INT           NOT NULL,
    production_id            INT           NOT NULL,
    bom_id                   INT           NOT NULL,
    raw_inventory_id         INT           NOT NULL,
    actual_consumed_quantity DECIMAL(18,3) NOT NULL,
    return_quantity          DECIMAL(18,3) NOT NULL,
    scrap_quantity           DECIMAL(18,3) NOT NULL,
    unit_cost                DECIMAL(18,2) NOT NULL,
    total_material_cost      DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_ProductionDetails PRIMARY KEY (production_detail_id),
    CONSTRAINT UQ_ProductionDetails_Line UNIQUE (production_id, bom_id, raw_inventory_id),
    CONSTRAINT FK_ProductionDetails_Production
        FOREIGN KEY (production_id) REFERENCES production.Production(production_id),
    CONSTRAINT FK_ProductionDetails_BOM
        FOREIGN KEY (bom_id) REFERENCES production.ProductBOM(bom_id),
    CONSTRAINT FK_ProductionDetails_RawInventory
        FOREIGN KEY (raw_inventory_id) REFERENCES inventory.RawMaterialInventory(raw_inventory_id),
    CONSTRAINT CK_ProductionDetails_Consumed CHECK (actual_consumed_quantity > 0),
    CONSTRAINT CK_ProductionDetails_Return CHECK (return_quantity >= 0),
    CONSTRAINT CK_ProductionDetails_Scrap CHECK (scrap_quantity >= 0),
    CONSTRAINT CK_ProductionDetails_Cost CHECK (unit_cost >= 0 AND total_material_cost >= 0)
);
GO

CREATE TABLE inventory.RawMaterialInventoryTransactions
(
    raw_transaction_id INT           NOT NULL,
    raw_inventory_id   INT           NOT NULL,
    production_id      INT           NOT NULL,
    inspection_id      INT           NOT NULL,
    transaction_type   VARCHAR(40)   NOT NULL,
    quantity           DECIMAL(18,3) NOT NULL,
    unit_cost          DECIMAL(18,2) NOT NULL,
    transaction_date   DATETIME2(0)  NOT NULL,
    reference_code     VARCHAR(50)   NOT NULL,

    CONSTRAINT PK_RawMaterialInventoryTransactions PRIMARY KEY (raw_transaction_id),
    CONSTRAINT FK_RawTransactions_RawInventory
        FOREIGN KEY (raw_inventory_id) REFERENCES inventory.RawMaterialInventory(raw_inventory_id),
    CONSTRAINT FK_RawTransactions_Production
        FOREIGN KEY (production_id) REFERENCES production.Production(production_id),
    CONSTRAINT FK_RawTransactions_QualityInspection
        FOREIGN KEY (inspection_id) REFERENCES inbound.QualityInspections(inspection_id),
    CONSTRAINT CK_RawTransactions_Quantity CHECK (quantity > 0),
    CONSTRAINT CK_RawTransactions_Cost CHECK (unit_cost >= 0)
);
GO

/*=============================================================================
 7. FINISHED GOODS, SALES & CUSTOMER SHIPMENTS
=============================================================================*/
CREATE TABLE sales.FinishedGoodsInventory
(
    finished_goods_inventory_id INT           NOT NULL,
    warehouse_id                INT           NOT NULL,
    product_id                  INT           NOT NULL,
    quantity_on_hand            DECIMAL(18,2) NOT NULL,
    quantity_reserved           INT           NOT NULL,
    reorder_point               DECIMAL(18,2) NOT NULL,
    safety_stock_level          DECIMAL(18,2) NOT NULL,
    last_updated_at             DATETIME2(0)  NOT NULL,

    CONSTRAINT PK_FinishedGoodsInventory PRIMARY KEY (finished_goods_inventory_id),
    CONSTRAINT UQ_FinishedGoodsInventory UNIQUE (warehouse_id, product_id),
    CONSTRAINT FK_FGInventory_Warehouses
        FOREIGN KEY (warehouse_id) REFERENCES inventory.Warehouses(warehouse_id),
    CONSTRAINT FK_FGInventory_Products
        FOREIGN KEY (product_id) REFERENCES production.Products(product_id),
    CONSTRAINT CK_FGInventory_Quantities
        CHECK (quantity_on_hand >= 0 AND quantity_reserved >= 0 AND quantity_reserved <= quantity_on_hand),
    CONSTRAINT CK_FGInventory_Levels
        CHECK (reorder_point >= 0 AND safety_stock_level >= 0 AND reorder_point >= safety_stock_level)
);
GO

CREATE TABLE sales.Customers
(
    customer_id                 INT           NOT NULL,
    customer_code               VARCHAR(30)   NOT NULL,
    customer_name               VARCHAR(100)  NOT NULL,
    customer_type               VARCHAR(50)   NOT NULL,
    email                       VARCHAR(120)  NULL,
    phone                       VARCHAR(20)   NOT NULL,
    country                     VARCHAR(50)   NOT NULL,
    city                        VARCHAR(50)   NOT NULL,
    address                     VARCHAR(250)  NOT NULL,
    registration_date           DATE          NOT NULL,
    default_discount_percentage DECIMAL(5,2)  NOT NULL,
    status                      VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_Customers PRIMARY KEY (customer_id),
    CONSTRAINT UQ_Customers_Code UNIQUE (customer_code),
    CONSTRAINT CK_Customers_Discount CHECK (default_discount_percentage BETWEEN 0 AND 100)
);
GO

CREATE TABLE sales.SalesOrders
(
    sales_order_id         INT           NOT NULL,
    sales_order_code       VARCHAR(20)   NOT NULL,
    customer_id            INT           NOT NULL,
    order_date             DATE          NOT NULL,
    required_delivery_date DATE          NOT NULL,
    payment_method         VARCHAR(30)   NOT NULL,
    tax_percentage         DECIMAL(5,2)  NOT NULL,
    sales_order_status     VARCHAR(30)   NOT NULL,

    CONSTRAINT PK_SalesOrders PRIMARY KEY (sales_order_id),
    CONSTRAINT UQ_SalesOrders_Code UNIQUE (sales_order_code),
    CONSTRAINT FK_SalesOrders_Customers
        FOREIGN KEY (customer_id) REFERENCES sales.Customers(customer_id),
    CONSTRAINT CK_SalesOrders_Dates CHECK (required_delivery_date >= order_date),
    CONSTRAINT CK_SalesOrders_Tax CHECK (tax_percentage BETWEEN 0 AND 100)
);
GO

CREATE TABLE sales.SalesOrderDetails
(
    sales_order_detail_id INT           NOT NULL,
    sales_order_id        INT           NOT NULL,
    product_id            INT           NOT NULL,
    ordered_quantity      DECIMAL(18,2) NOT NULL,
    line_status           VARCHAR(30)   NOT NULL,

    CONSTRAINT PK_SalesOrderDetails PRIMARY KEY (sales_order_detail_id),
    CONSTRAINT UQ_SalesOrderDetails_Line UNIQUE (sales_order_id, product_id),
    CONSTRAINT FK_SalesOrderDetails_Orders
        FOREIGN KEY (sales_order_id) REFERENCES sales.SalesOrders(sales_order_id),
    CONSTRAINT FK_SalesOrderDetails_Products
        FOREIGN KEY (product_id) REFERENCES production.Products(product_id),
    CONSTRAINT CK_SalesOrderDetails_Quantity CHECK (ordered_quantity > 0)
);
GO

CREATE TABLE sales.CustomerShipments
(
    customer_shipment_id   INT           NOT NULL,
    shipment_code          VARCHAR(20)   NOT NULL,
    sales_order_id         INT           NOT NULL,
    warehouse_id           INT           NOT NULL,
    shipment_date          DATE          NOT NULL,
    expected_delivery_date DATE          NOT NULL,
    actual_delivery_date   DATE          NULL,
    tracking_number        VARCHAR(50)   NOT NULL,
    shipping_method        VARCHAR(30)   NOT NULL,
    shipping_cost          DECIMAL(18,2) NOT NULL,
    delivery_address       VARCHAR(300)  NOT NULL,
    shipment_status        VARCHAR(30)   NOT NULL,
    delivery_confirmation  BIT           NOT NULL,
    customer_feedback      VARCHAR(500)  NOT NULL,

    CONSTRAINT PK_CustomerShipments PRIMARY KEY (customer_shipment_id),
    CONSTRAINT UQ_CustomerShipments_Code UNIQUE (shipment_code),
    CONSTRAINT UQ_CustomerShipments_Order UNIQUE (sales_order_id),
    CONSTRAINT UQ_CustomerShipments_Tracking UNIQUE (tracking_number),
    CONSTRAINT FK_CustomerShipments_SalesOrders
        FOREIGN KEY (sales_order_id) REFERENCES sales.SalesOrders(sales_order_id),
    CONSTRAINT FK_CustomerShipments_Warehouses
        FOREIGN KEY (warehouse_id) REFERENCES inventory.Warehouses(warehouse_id),
    CONSTRAINT CK_CustomerShipments_Dates
        CHECK (
            expected_delivery_date >= shipment_date
            AND (actual_delivery_date IS NULL OR actual_delivery_date >= shipment_date)
        ),
    CONSTRAINT CK_CustomerShipments_Cost CHECK (shipping_cost >= 0)
);
GO

CREATE TABLE sales.CustomerShipmentDetails
(
    customer_shipment_detail_id INT           NOT NULL,
    customer_shipment_id        INT           NOT NULL,
    sales_order_detail_id       INT           NOT NULL,
    shipped_quantity            DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_CustomerShipmentDetails PRIMARY KEY (customer_shipment_detail_id),
    CONSTRAINT UQ_CustomerShipmentDetails_Line UNIQUE (customer_shipment_id, sales_order_detail_id),
    CONSTRAINT FK_CustomerShipmentDetails_Shipments
        FOREIGN KEY (customer_shipment_id) REFERENCES sales.CustomerShipments(customer_shipment_id),
    CONSTRAINT FK_CustomerShipmentDetails_SalesOrderDetails
        FOREIGN KEY (sales_order_detail_id) REFERENCES sales.SalesOrderDetails(sales_order_detail_id),
    CONSTRAINT CK_CustomerShipmentDetails_Quantity CHECK (shipped_quantity > 0)
);
GO

CREATE TABLE sales.FinishedGoodsInventoryTransactions
(
    finished_inventory_transaction_id INT           NOT NULL,
    finished_goods_inventory_id       INT           NOT NULL,
    production_id                     INT           NOT NULL,
    customer_shipment_detail_id       INT           NOT NULL,
    transaction_type                  VARCHAR(40)   NOT NULL,
    quantity                          DECIMAL(18,2) NOT NULL,
    unit_cost                         DECIMAL(18,2) NOT NULL,
    transaction_date                  DATETIME2(0)  NOT NULL,
    reference_code                    VARCHAR(50)   NOT NULL,

    CONSTRAINT PK_FGInventoryTransactions PRIMARY KEY (finished_inventory_transaction_id),
    CONSTRAINT FK_FGTransactions_Inventory
        FOREIGN KEY (finished_goods_inventory_id) REFERENCES sales.FinishedGoodsInventory(finished_goods_inventory_id),
    CONSTRAINT FK_FGTransactions_Production
        FOREIGN KEY (production_id) REFERENCES production.Production(production_id),
    CONSTRAINT FK_FGTransactions_CustomerShipmentDetails
        FOREIGN KEY (customer_shipment_detail_id)
        REFERENCES sales.CustomerShipmentDetails(customer_shipment_detail_id),
    CONSTRAINT CK_FGTransactions_Quantity CHECK (quantity > 0),
    CONSTRAINT CK_FGTransactions_Cost CHECK (unit_cost >= 0)
);
GO

/*=============================================================================
 8. RETURNS
=============================================================================*/
CREATE TABLE returns_data.Returns
(
    return_id                   INT           NOT NULL,
    return_code                 VARCHAR(20)   NOT NULL,
    customer_shipment_detail_id INT           NOT NULL,
    return_request_date         DATE          NOT NULL,
    return_received_date        DATE          NOT NULL,
    returned_quantity           DECIMAL(18,2) NOT NULL,
    return_reason               VARCHAR(120)  NOT NULL,
    product_condition           VARCHAR(50)   NOT NULL,
    return_status               VARCHAR(30)   NOT NULL,

    CONSTRAINT PK_Returns PRIMARY KEY (return_id),
    CONSTRAINT UQ_Returns_Code UNIQUE (return_code),
    CONSTRAINT FK_Returns_CustomerShipmentDetails
        FOREIGN KEY (customer_shipment_detail_id)
        REFERENCES sales.CustomerShipmentDetails(customer_shipment_detail_id),
    CONSTRAINT CK_Returns_Quantity CHECK (returned_quantity > 0),
    CONSTRAINT CK_Returns_Dates CHECK (return_received_date >= return_request_date)
);
GO

/*=============================================================================
 9. INDEXES FOR FOREIGN KEYS AND ANALYTICS
=============================================================================*/
CREATE INDEX IX_SupplierMaterials_Supplier ON procurement.SupplierMaterials(supplier_id);
CREATE INDEX IX_SupplierMaterials_Material ON procurement.SupplierMaterials(material_id);
CREATE INDEX IX_PR_Department ON procurement.PurchaseRequisitions(department_id);
CREATE INDEX IX_PR_ApprovalStatus ON procurement.PurchaseRequisitions(approval_status);
CREATE INDEX IX_PRDetails_PR ON procurement.PurchaseRequisitionDetails(pr_id);
CREATE INDEX IX_PO_Supplier ON procurement.PurchaseOrders(supplier_id);
CREATE INDEX IX_PO_PR ON procurement.PurchaseOrders(pr_id);
CREATE INDEX IX_PODetails_PO ON procurement.PurchaseOrderDetails(po_id);

CREATE INDEX IX_SupplierShipments_PO ON inbound.SupplierShipments(po_id);
CREATE INDEX IX_SupplierShipments_Supplier ON inbound.SupplierShipments(supplier_id);
CREATE INDEX IX_SupplierShipments_Arrival ON inbound.SupplierShipments(expected_arrival_date, actual_arrival_date);
CREATE INDEX IX_SupplierShipmentDetails_PO ON inbound.SupplierShipmentDetails(po_detail_id);
CREATE INDEX IX_GoodsReceipts_Shipment ON inbound.GoodsReceipts(shipment_id);
CREATE INDEX IX_GoodsReceiptDetails_Material ON inbound.GoodsReceiptDetails(material_id);
CREATE INDEX IX_QualityInspections_GRDetail ON inbound.QualityInspections(gr_detail_id);
CREATE INDEX IX_SupplierInvoices_Supplier ON inbound.SupplierInvoices(supplier_id);
CREATE INDEX IX_SupplierPayments_Invoice ON inbound.SupplierPayments(invoice_id);

CREATE INDEX IX_RawInventory_Material ON inventory.RawMaterialInventory(material_id);
CREATE INDEX IX_RawInventory_Warehouse ON inventory.RawMaterialInventory(warehouse_id);
CREATE INDEX IX_RawInventory_Reorder ON inventory.RawMaterialInventory(reorder_point, quantity_on_hand);
CREATE INDEX IX_RawTransactions_Date ON inventory.RawMaterialInventoryTransactions(transaction_date);
CREATE INDEX IX_RawTransactions_Inventory ON inventory.RawMaterialInventoryTransactions(raw_inventory_id);

CREATE INDEX IX_ProductBOM_Product ON production.ProductBOM(product_id);
CREATE INDEX IX_ProductBOM_Material ON production.ProductBOM(material_id);
CREATE INDEX IX_Production_Product ON production.Production(product_id);
CREATE INDEX IX_Production_Dates ON production.Production(start_date, expected_end_date, actual_end_date);
CREATE INDEX IX_ProductionDetails_Production ON production.ProductionDetails(production_id);

CREATE INDEX IX_FGInventory_Product ON sales.FinishedGoodsInventory(product_id);
CREATE INDEX IX_FGInventory_Warehouse ON sales.FinishedGoodsInventory(warehouse_id);
CREATE INDEX IX_Customers_City ON sales.Customers(city);
CREATE INDEX IX_Customers_Type ON sales.Customers(customer_type);
CREATE INDEX IX_Customers_Status ON sales.Customers(status);
CREATE INDEX IX_SalesOrders_Customer ON sales.SalesOrders(customer_id);
CREATE INDEX IX_SalesOrders_OrderDate ON sales.SalesOrders(order_date);
CREATE INDEX IX_SalesOrderDetails_Order ON sales.SalesOrderDetails(sales_order_id);
CREATE INDEX IX_SalesOrderDetails_Product ON sales.SalesOrderDetails(product_id);
CREATE INDEX IX_CustomerShipments_Order ON sales.CustomerShipments(sales_order_id);
CREATE INDEX IX_CustomerShipments_Status ON sales.CustomerShipments(shipment_status);
CREATE INDEX IX_CustomerShipments_DeliveryDates ON sales.CustomerShipments(expected_delivery_date, actual_delivery_date);
CREATE INDEX IX_CustomerShipmentDetails_Shipment ON sales.CustomerShipmentDetails(customer_shipment_id);
CREATE INDEX IX_FGTransactions_Inventory ON sales.FinishedGoodsInventoryTransactions(finished_goods_inventory_id);
CREATE INDEX IX_FGTransactions_Date ON sales.FinishedGoodsInventoryTransactions(transaction_date);
CREATE INDEX IX_Returns_ShipmentDetail ON returns_data.Returns(customer_shipment_detail_id);
CREATE INDEX IX_Returns_Condition ON returns_data.Returns(product_condition);
GO

/*=============================================================================
 10. RELATIONSHIP SUMMARY
=============================================================================
 Procurement
 -----------
 Departments 1 ---- * PurchaseRequisitions
 PurchaseRequisitions 1 ---- * PurchaseRequisitionDetails
 Suppliers * ---- * Materials through SupplierMaterials
 PurchaseRequisitions 1 ---- 0..1 PurchaseOrders
 Suppliers 1 ---- * PurchaseOrders
 PurchaseOrders 1 ---- * PurchaseOrderDetails
 PurchaseRequisitionDetails 1 ---- 0..1 PurchaseOrderDetails

 Inbound / Quality / Finance
 ---------------------------
 PurchaseOrders 1 ---- 1 SupplierShipments (current generated dataset)
 PurchaseOrderDetails 1 ---- 1 SupplierShipmentDetails (current generated dataset)
 SupplierShipments 1 ---- 1 GoodsReceipts
 SupplierShipmentDetails 1 ---- 1 GoodsReceiptDetails
 GoodsReceiptDetails 1 ---- 1 QualityInspections
 SupplierShipments 1 ---- 1 SupplierInvoices
 SupplierInvoices 1 ---- * SupplierInvoiceDetails
 SupplierInvoices 1 ---- * SupplierPayments

 Inventory / Production
 ----------------------
 Warehouses 1 ---- * RawMaterialInventory
 Materials 1 ---- * RawMaterialInventory
 Products * ---- * Materials through ProductBOM
 Products 1 ---- * Production
 Production 1 ---- * ProductionDetails
 RawMaterialInventory 1 ---- * ProductionDetails
 RawMaterialInventory 1 ---- * RawMaterialInventoryTransactions
 Production 1 ---- * RawMaterialInventoryTransactions
 QualityInspections 1 ---- * RawMaterialInventoryTransactions

 Sales / Delivery / Returns
 --------------------------
 Warehouses 1 ---- * FinishedGoodsInventory
 Products 1 ---- * FinishedGoodsInventory
 Customers 1 ---- * SalesOrders
 SalesOrders 1 ---- * SalesOrderDetails
 Products 1 ---- * SalesOrderDetails
 SalesOrders 1 ---- 1 CustomerShipments (current generated dataset)
 CustomerShipments 1 ---- * CustomerShipmentDetails
 SalesOrderDetails 1 ---- 1 CustomerShipmentDetails (current generated dataset)
 FinishedGoodsInventory 1 ---- * FinishedGoodsInventoryTransactions
 Production 1 ---- * FinishedGoodsInventoryTransactions
 CustomerShipmentDetails 1 ---- * FinishedGoodsInventoryTransactions
 CustomerShipmentDetails 1 ---- * Returns
=============================================================================*/

/*=============================================================================
 11. POST-CREATION CHECK
=============================================================================*/
DECLARE @BusinessTableCount INT =
(
    SELECT COUNT(*)
    FROM sys.tables t
    JOIN sys.schemas s ON s.schema_id = t.schema_id
    WHERE s.name IN ('procurement','inbound','inventory','production','sales','returns_data')
);

PRINT 'ElectronicsSupplyChainDB created successfully.';
PRINT 'Business tables created: ' + CAST(@BusinessTableCount AS VARCHAR(10));
PRINT 'Expected business tables: 31';
PRINT 'DDL is aligned with the FINAL 200,000-row CSV generator.';
GO
