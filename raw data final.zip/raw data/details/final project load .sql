﻿/*
=========================================================
              ElectronicsSupplyChainDB
              DATA LOADING SCRIPT
=========================================================
*/

USE ElectronicsSupplyChainDB;
GO


/*=========================================================
                  DELETE ALL DATA
=========================================================*/

DELETE FROM returns_data.Returns;

DELETE FROM sales.FinishedGoodsInventoryTransactions;
DELETE FROM sales.CustomerShipmentDetails;
DELETE FROM sales.CustomerShipments;
DELETE FROM sales.SalesOrderDetails;
DELETE FROM sales.SalesOrders;
DELETE FROM sales.Customers;
DELETE FROM sales.FinishedGoodsInventory;

DELETE FROM inventory.RawMaterialInventoryTransactions;

DELETE FROM production.ProductionDetails;
DELETE FROM production.Production;
DELETE FROM production.ProductBOM;
DELETE FROM production.Products;

DELETE FROM inventory.RawMaterialInventory;
DELETE FROM inventory.Warehouses;

DELETE FROM inbound.SupplierPayments;
DELETE FROM inbound.SupplierInvoiceDetails;
DELETE FROM inbound.SupplierInvoices;
DELETE FROM inbound.QualityInspections;
DELETE FROM inbound.GoodsReceiptDetails;
DELETE FROM inbound.GoodsReceipts;
DELETE FROM inbound.SupplierShipmentDetails;
DELETE FROM inbound.SupplierShipments;

DELETE FROM procurement.PurchaseOrderDetails;
DELETE FROM procurement.PurchaseOrders;
DELETE FROM procurement.PurchaseRequisitionDetails;
DELETE FROM procurement.PurchaseRequisitions;
DELETE FROM procurement.SupplierMaterials;
DELETE FROM procurement.Suppliers;
DELETE FROM procurement.Materials;
DELETE FROM procurement.Departments;


/*=========================================================
                      PROCUREMENT
=========================================================*/

BULK INSERT procurement.Departments
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\Departments.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT procurement.Materials
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\Materials.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT procurement.Suppliers
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\Suppliers.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT procurement.SupplierMaterials
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\SupplierMaterials.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT procurement.PurchaseRequisitions
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\PurchaseRequisitions.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT procurement.PurchaseRequisitionDetails
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\PurchaseRequisitionDetails.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT procurement.PurchaseOrders
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\PurchaseOrders.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT procurement.PurchaseOrderDetails
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\PurchaseOrderDetails.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);


/*=========================================================
                  INBOUND & QUALITY
=========================================================*/

BULK INSERT inbound.SupplierShipments
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\SupplierShipments.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT inbound.SupplierShipmentDetails
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\SupplierShipmentDetails.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT inbound.GoodsReceipts
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\GoodsReceipts.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT inbound.GoodsReceiptDetails
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\GoodsReceiptDetails.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT inbound.QualityInspections
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\QualityInspections.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT inbound.SupplierInvoices
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\SupplierInvoices.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT inbound.SupplierInvoiceDetails
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\SupplierInvoiceDetails.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT inbound.SupplierPayments
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\SupplierPayments.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);


/*=========================================================
                      INVENTORY
=========================================================*/

BULK INSERT inventory.Warehouses
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\Warehouses.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT inventory.RawMaterialInventory
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\RawMaterialInventory.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);


/*=========================================================
                      PRODUCTION
=========================================================*/

BULK INSERT production.Products
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\Products.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT production.ProductBOM
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\ProductBOM.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT production.Production
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\Production.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT production.ProductionDetails
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\ProductionDetails.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT inventory.RawMaterialInventoryTransactions
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\RawMaterialInventoryTransactions.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);


/*=========================================================
                        SALES
=========================================================*/

BULK INSERT sales.FinishedGoodsInventory
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\FinishedGoodsInventory.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT sales.Customers
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\Customers.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT sales.SalesOrders
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\SalesOrders.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT sales.SalesOrderDetails
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\SalesOrderDetails.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT sales.CustomerShipments
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\CustomerShipments.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT sales.CustomerShipmentDetails
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\CustomerShipmentDetails.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);

BULK INSERT sales.FinishedGoodsInventoryTransactions
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\FinishedGoodsInventoryTransactions.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);


/*=========================================================
                        RETURNS
=========================================================*/

BULK INSERT returns_data.Returns
FROM 'C:\Users\A-FF-L5-D16\Desktop\raw data\Returns.csv'
WITH
(
    FORMAT = 'CSV',
    FIRSTROW = 2,
    FIELDQUOTE = '"',
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001'
);


/*=========================================================
              FINAL VALIDATION - 31 TABLES
=========================================================*/

WITH Validation AS
(
    SELECT 1 AS load_order, 'procurement.Departments' AS table_name,
           (SELECT COUNT(*) FROM procurement.Departments) AS row_count

    UNION ALL SELECT 2, 'procurement.Materials',
           (SELECT COUNT(*) FROM procurement.Materials)
    UNION ALL SELECT 3, 'procurement.Suppliers',
           (SELECT COUNT(*) FROM procurement.Suppliers)
    UNION ALL SELECT 4, 'procurement.SupplierMaterials',
           (SELECT COUNT(*) FROM procurement.SupplierMaterials)
    UNION ALL SELECT 5, 'procurement.PurchaseRequisitions',
           (SELECT COUNT(*) FROM procurement.PurchaseRequisitions)
    UNION ALL SELECT 6, 'procurement.PurchaseRequisitionDetails',
           (SELECT COUNT(*) FROM procurement.PurchaseRequisitionDetails)
    UNION ALL SELECT 7, 'procurement.PurchaseOrders',
           (SELECT COUNT(*) FROM procurement.PurchaseOrders)
    UNION ALL SELECT 8, 'procurement.PurchaseOrderDetails',
           (SELECT COUNT(*) FROM procurement.PurchaseOrderDetails)

    UNION ALL SELECT 9, 'inbound.SupplierShipments',
           (SELECT COUNT(*) FROM inbound.SupplierShipments)
    UNION ALL SELECT 10, 'inbound.SupplierShipmentDetails',
           (SELECT COUNT(*) FROM inbound.SupplierShipmentDetails)
    UNION ALL SELECT 11, 'inbound.GoodsReceipts',
           (SELECT COUNT(*) FROM inbound.GoodsReceipts)
    UNION ALL SELECT 12, 'inbound.GoodsReceiptDetails',
           (SELECT COUNT(*) FROM inbound.GoodsReceiptDetails)
    UNION ALL SELECT 13, 'inbound.QualityInspections',
           (SELECT COUNT(*) FROM inbound.QualityInspections)
    UNION ALL SELECT 14, 'inbound.SupplierInvoices',
           (SELECT COUNT(*) FROM inbound.SupplierInvoices)
    UNION ALL SELECT 15, 'inbound.SupplierInvoiceDetails',
           (SELECT COUNT(*) FROM inbound.SupplierInvoiceDetails)
    UNION ALL SELECT 16, 'inbound.SupplierPayments',
           (SELECT COUNT(*) FROM inbound.SupplierPayments)

    UNION ALL SELECT 17, 'inventory.Warehouses',
           (SELECT COUNT(*) FROM inventory.Warehouses)
    UNION ALL SELECT 18, 'inventory.RawMaterialInventory',
           (SELECT COUNT(*) FROM inventory.RawMaterialInventory)

    UNION ALL SELECT 19, 'production.Products',
           (SELECT COUNT(*) FROM production.Products)
    UNION ALL SELECT 20, 'production.ProductBOM',
           (SELECT COUNT(*) FROM production.ProductBOM)
    UNION ALL SELECT 21, 'production.Production',
           (SELECT COUNT(*) FROM production.Production)
    UNION ALL SELECT 22, 'production.ProductionDetails',
           (SELECT COUNT(*) FROM production.ProductionDetails)

    UNION ALL SELECT 23, 'inventory.RawMaterialInventoryTransactions',
           (SELECT COUNT(*) FROM inventory.RawMaterialInventoryTransactions)

    UNION ALL SELECT 24, 'sales.FinishedGoodsInventory',
           (SELECT COUNT(*) FROM sales.FinishedGoodsInventory)
    UNION ALL SELECT 25, 'sales.Customers',
           (SELECT COUNT(*) FROM sales.Customers)
    UNION ALL SELECT 26, 'sales.SalesOrders',
           (SELECT COUNT(*) FROM sales.SalesOrders)
    UNION ALL SELECT 27, 'sales.SalesOrderDetails',
           (SELECT COUNT(*) FROM sales.SalesOrderDetails)
    UNION ALL SELECT 28, 'sales.CustomerShipments',
           (SELECT COUNT(*) FROM sales.CustomerShipments)
    UNION ALL SELECT 29, 'sales.CustomerShipmentDetails',
           (SELECT COUNT(*) FROM sales.CustomerShipmentDetails)
    UNION ALL SELECT 30, 'sales.FinishedGoodsInventoryTransactions',
           (SELECT COUNT(*) FROM sales.FinishedGoodsInventoryTransactions)

    UNION ALL SELECT 31, 'returns_data.Returns',
           (SELECT COUNT(*) FROM returns_data.Returns)
)

SELECT
    load_order,
    table_name,
    row_count,
    CASE
        WHEN row_count > 0 THEN 'PASS'
        ELSE 'EMPTY'
    END AS validation_status
FROM Validation
ORDER BY load_order;
GO
