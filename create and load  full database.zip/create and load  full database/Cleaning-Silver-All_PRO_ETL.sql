USE ElectronicsSupplyChainDB;
GO

/*
===============================================================================
  BRONZE -> SILVER ETL PIPELINE
===============================================================================
*/

CREATE OR ALTER PROCEDURE Refresh_Silver_Data
AS
BEGIN
  
    DECLARE @PipelineStart DATETIME2(7) = SYSDATETIME();
    DECLARE @TableStart    DATETIME2(7);
    DECLARE @RowsLoaded    INT;

    CREATE TABLE #ETL_Load_Log
    (
        load_order      INT            NOT NULL,
        table_name      VARCHAR(128)   NOT NULL,
        rows_loaded     INT            NOT NULL,
        column_count    INT            NOT NULL,
        duration_ms     BIGINT         NOT NULL,
        load_status     VARCHAR(20)    NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;

        /*=====================================================================
          DELETE OLD SILVER DATA
          Child -> Parent to respect FK relationships
        =====================================================================*/
        DELETE FROM silver.Returns;

        DELETE FROM silver.FinishedGoodsInventoryTransactions;
        DELETE FROM silver.CustomerShipmentDetails;
        DELETE FROM silver.CustomerShipments;
        DELETE FROM silver.SalesOrderDetails;
        DELETE FROM silver.SalesOrders;
        DELETE FROM silver.Customers;
        DELETE FROM silver.FinishedGoodsInventory;

        DELETE FROM silver.RawMaterialInventoryTransactions;

        DELETE FROM silver.ProductionDetails;
        DELETE FROM silver.Production;
        DELETE FROM silver.ProductBOM;
        DELETE FROM silver.Products;

        DELETE FROM silver.RawMaterialInventory;
        DELETE FROM silver.Warehouses;

        DELETE FROM silver.SupplierPayments;
        DELETE FROM silver.SupplierInvoiceDetails;
        DELETE FROM silver.SupplierInvoices;
        DELETE FROM silver.QualityInspections;
        DELETE FROM silver.GoodsReceiptDetails;
        DELETE FROM silver.GoodsReceipts;
        DELETE FROM silver.SupplierShipmentDetails;
        DELETE FROM silver.SupplierShipments;

        DELETE FROM silver.PurchaseOrderDetails;
        DELETE FROM silver.PurchaseOrders;
        DELETE FROM silver.PurchaseRequisitionDetails;
        DELETE FROM silver.PurchaseRequisitions;

        DELETE FROM silver.SupplierMaterials;
        DELETE FROM silver.Suppliers;
        DELETE FROM silver.Materials;
        DELETE FROM silver.Departments;


        /*=====================================================================
          01. Departments
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.Departments
        (
            department_id,
            department_code,
            department_name,
            department_description,
            status
        )
        SELECT
            department_id,
            UPPER(TRIM(department_code)),
            TRIM(department_name),
            TRIM(department_description),
            CASE
                WHEN LOWER(TRIM(status)) = 'active'   THEN 'Active'
                WHEN LOWER(TRIM(status)) = 'inactive' THEN 'Inactive'
                ELSE COALESCE(NULLIF(TRIM(status), ''), 'Unknown')
            END
        FROM bronze.Departments;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 1, 'silver.Departments', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.Departments');


        /*=====================================================================
          02. Materials
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.Materials
        (
            material_id,
            material_code,
            material_name,
            material_category,
            material_type,
            uom,
            unit_weight,
            status
        )
        SELECT
            material_id,
            UPPER(TRIM(material_code)),
            TRIM(material_name),
            COALESCE(NULLIF(TRIM(material_category), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(material_type), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(uom), ''), 'Unknown'),
            COALESCE(unit_weight, 0),
            CASE
                WHEN LOWER(TRIM(status)) = 'active'   THEN 'Active'
                WHEN LOWER(TRIM(status)) = 'inactive' THEN 'Inactive'
                ELSE COALESCE(NULLIF(TRIM(status), ''), 'Unknown')
            END
        FROM bronze.Materials;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 2, 'silver.Materials', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.Materials');


        /*=====================================================================
          03. Suppliers
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.Suppliers
        (
            supplier_id,
            supplier_code,
            supplier_name,
            supplier_type,
            supplier_category,
            country,
            city,
            address,
            contact_person,
            phone,
            email,
            payment_terms,
            status
        )
        SELECT
            supplier_id,
            COALESCE(NULLIF(UPPER(TRIM(supplier_code)), ''), 'UNKNOWN'),
            COALESCE(NULLIF(TRIM(supplier_name), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(supplier_type), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(supplier_category), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(country), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(city), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(address), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(contact_person), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(phone), ''), 'Unknown'),
            COALESCE(NULLIF(LOWER(TRIM(email)), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(payment_terms), ''), 'Unknown'),
            CASE
                WHEN LOWER(TRIM(status)) = 'active'   THEN 'Active'
                WHEN LOWER(TRIM(status)) = 'inactive' THEN 'Inactive'
                ELSE COALESCE(NULLIF(TRIM(status), ''), 'Unknown')
            END
        FROM bronze.Suppliers;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 3, 'silver.Suppliers', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.Suppliers');


        /*=====================================================================
          04. SupplierMaterials
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.SupplierMaterials
        (
            supplier_material_id,
            supplier_id,
            material_id,
            supplier_material_code,
            standard_price,
            lead_time_days,
            minimum_order_quantity,
            preferred_supplier,
            status
        )
        SELECT
            supplier_material_id,
            supplier_id,
            material_id,
            COALESCE(NULLIF(UPPER(TRIM(supplier_material_code)), ''), 'UNKNOWN'),
            COALESCE(standard_price, 0),
            COALESCE(lead_time_days, 0),
            COALESCE(minimum_order_quantity, 0),
            CASE WHEN preferred_supplier = 1 THEN 1 ELSE 0 END,
            CASE
                WHEN LOWER(TRIM(status)) = 'active'   THEN 'Active'
                WHEN LOWER(TRIM(status)) = 'inactive' THEN 'Inactive'
                ELSE COALESCE(NULLIF(TRIM(status), ''), 'Unknown')
            END
        FROM bronze.SupplierMaterials;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 4, 'silver.SupplierMaterials', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.SupplierMaterials');


        /*=====================================================================
          05. PurchaseRequisitions
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.PurchaseRequisitions
        (
            pr_id,
            pr_code,
            department_id,
            requested_by,
            request_date,
            order_date,
            required_date,
            priority,
            approval_status,
            approved_by,
            approval_date,
            rejection_reason,
            created_date
        )
        SELECT
            pr_id,
            COALESCE(NULLIF(UPPER(TRIM(pr_code)), ''), 'UNKNOWN'),
            department_id,
            COALESCE(NULLIF(TRIM(requested_by), ''), 'Unknown'),
            TRY_CONVERT(DATE, request_date),
            TRY_CONVERT(DATE, order_date),
            TRY_CONVERT(DATE, required_date),
            CASE
                WHEN LOWER(TRIM(priority)) = 'normal' THEN 'Normal'
                WHEN LOWER(TRIM(priority)) = 'high'   THEN 'High'
                WHEN LOWER(TRIM(priority)) = 'urgent' THEN 'Urgent'
                ELSE COALESCE(NULLIF(TRIM(priority), ''), 'Unknown')
            END,
            CASE
                WHEN LOWER(TRIM(approval_status)) = 'approved' THEN 'Approved'
                WHEN LOWER(TRIM(approval_status)) = 'rejected' THEN 'Rejected'
                WHEN LOWER(TRIM(approval_status)) = 'pending'  THEN 'Pending'
                ELSE COALESCE(NULLIF(TRIM(approval_status), ''), 'Unknown')
            END,
            COALESCE(NULLIF(TRIM(approved_by), ''), 'Unknown'),
            TRY_CONVERT(DATE, approval_date),
            CASE
                WHEN LOWER(TRIM(approval_status)) = 'approved'
                     AND NULLIF(TRIM(rejection_reason), '') IS NULL
                    THEN 'No Rejection'
                WHEN LOWER(TRIM(approval_status)) = 'rejected'
                     AND NULLIF(TRIM(rejection_reason), '') IS NULL
                    THEN 'Not Provided'
                ELSE COALESCE(NULLIF(TRIM(rejection_reason), ''), 'Unknown')
            END,
            TRY_CONVERT(DATETIME2(0), created_date)
        FROM bronze.PurchaseRequisitions;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 5, 'silver.PurchaseRequisitions', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.PurchaseRequisitions');


        /*=====================================================================
          06. PurchaseRequisitionDetails
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.PurchaseRequisitionDetails
        (
            pr_detail_id,
            pr_id,
            material_id,
            requested_quantity,
            estimated_unit_cost
        )
        SELECT
            pr_detail_id,
            pr_id,
            material_id,
            COALESCE(requested_quantity, 0),
            COALESCE(estimated_unit_cost, 0)
        FROM bronze.PurchaseRequisitionDetails;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 6, 'silver.PurchaseRequisitionDetails', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.PurchaseRequisitionDetails');


        /*=====================================================================
          07. PurchaseOrders
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.PurchaseOrders
        (
            po_id,
            po_code,
            supplier_id,
            pr_id,
            order_date,
            expected_delivery_date,
            payment_terms,
            status
        )
        SELECT
            po_id,
            COALESCE(NULLIF(UPPER(TRIM(po_code)), ''), 'UNKNOWN'),
            supplier_id,
            pr_id,
            TRY_CONVERT(DATE, order_date),
            TRY_CONVERT(DATE, expected_delivery_date),
            COALESCE(NULLIF(TRIM(payment_terms), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(status), ''), 'Unknown')
        FROM bronze.PurchaseOrders;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 7, 'silver.PurchaseOrders', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.PurchaseOrders');


        /*=====================================================================
          08. PurchaseOrderDetails
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.PurchaseOrderDetails
        (
            po_detail_id,
            po_id,
            pr_detail_id,
            material_id,
            ordered_quantity,
            unit_price,
            discount_percentage,
            expected_delivery_date,
            total_amount,
            line_status
        )
        SELECT
            po_detail_id,
            po_id,
            pr_detail_id,
            material_id,
            COALESCE(ordered_quantity, 0),
            COALESCE(unit_price, 0),
            COALESCE(discount_percentage, 0),
            TRY_CONVERT(DATE, expected_delivery_date),
            COALESCE(total_amount, 0),
            COALESCE(NULLIF(TRIM(line_status), ''), 'Unknown')
        FROM bronze.PurchaseOrderDetails;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 8, 'silver.PurchaseOrderDetails', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.PurchaseOrderDetails');


        /*=====================================================================
          09. SupplierShipments
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.SupplierShipments
        (
            shipment_id,
            shipment_code,
            po_id,
            supplier_id,
            supplier_reference,
            ship_date,
            expected_arrival_date,
            actual_arrival_date,
            total_shipment_value,
            shipping_cost
        )
        SELECT
            shipment_id,
            COALESCE(NULLIF(UPPER(TRIM(shipment_code)), ''), 'UNKNOWN'),
            po_id,
            supplier_id,
            COALESCE(NULLIF(TRIM(supplier_reference), ''), 'Unknown'),
            TRY_CONVERT(DATE, ship_date),
            TRY_CONVERT(DATE, expected_arrival_date),
            TRY_CONVERT(DATE, actual_arrival_date),
            COALESCE(total_shipment_value, 0),
            COALESCE(shipping_cost, 0)
        FROM bronze.SupplierShipments;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 9, 'silver.SupplierShipments', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.SupplierShipments');


        /*=====================================================================
          10. SupplierShipmentDetails
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.SupplierShipmentDetails
        (
            shipment_detail_id,
            shipment_id,
            po_detail_id,
            material_id,
            received_quantity,
            accepted_quantity,
            rejected_quantity
        )
        SELECT
            shipment_detail_id,
            shipment_id,
            po_detail_id,
            material_id,
            COALESCE(received_quantity, 0),
            COALESCE(accepted_quantity, 0),
            COALESCE(rejected_quantity, 0)
        FROM bronze.SupplierShipmentDetails;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 10, 'silver.SupplierShipmentDetails', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.SupplierShipmentDetails');


        /*=====================================================================
          11. GoodsReceipts
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.GoodsReceipts
        (
            gr_id,
            gr_code,
            shipment_id,
            receipt_date,
            received_by,
            quality_check_status,
            total_received_value
        )
        SELECT
            gr_id,
            COALESCE(NULLIF(UPPER(TRIM(gr_code)), ''), 'UNKNOWN'),
            shipment_id,
            TRY_CONVERT(DATE, receipt_date),
            COALESCE(NULLIF(TRIM(received_by), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(quality_check_status), ''), 'Unknown'),
            COALESCE(total_received_value, 0)
        FROM bronze.GoodsReceipts;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 11, 'silver.GoodsReceipts', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.GoodsReceipts');


        /*=====================================================================
          12. GoodsReceiptDetails
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.GoodsReceiptDetails
        (
            gr_detail_id,
            gr_id,
            shipment_detail_id,
            material_id,
            received_quantity,
            accepted_quantity,
            rejected_quantity,
            inspection_status,
            batch_number
        )
        SELECT
            gr_detail_id,
            gr_id,
            shipment_detail_id,
            material_id,
            COALESCE(received_quantity, 0),
            COALESCE(accepted_quantity, 0),
            COALESCE(rejected_quantity, 0),
            COALESCE(NULLIF(TRIM(inspection_status), ''), 'Unknown'),
            COALESCE(NULLIF(UPPER(TRIM(batch_number)), ''), 'UNKNOWN')
        FROM bronze.GoodsReceiptDetails;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 12, 'silver.GoodsReceiptDetails', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.GoodsReceiptDetails');


        /*=====================================================================
          13. QualityInspections
          No WHERE filtering: bad records are not silently discarded.
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.QualityInspections
        (
            inspection_id,
            gr_detail_id,
            inspection_date,
            inspection_type,
            inspected_quantity,
            passed_quantity,
            inspection_result,
            defect_quantity,
            defect_reason,
            corrective_action,
            reinspection_required,
            status
        )
        SELECT
            inspection_id,
            gr_detail_id,
            TRY_CONVERT(DATE, inspection_date),
            COALESCE(NULLIF(TRIM(inspection_type), ''), 'Unknown'),
            COALESCE(TRY_CONVERT(INT, inspected_quantity), 0),
            COALESCE(TRY_CONVERT(INT, passed_quantity), 0),
            COALESCE(NULLIF(TRIM(inspection_result), ''), 'Unknown'),
            COALESCE(TRY_CONVERT(INT, defect_quantity), 0),
            COALESCE(NULLIF(TRIM(defect_reason), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(corrective_action), ''), 'Unknown'),
            CASE WHEN reinspection_required = 1 THEN 1 ELSE 0 END,
            COALESCE(NULLIF(TRIM(status), ''), 'Unknown')
        FROM bronze.QualityInspections;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 13, 'silver.QualityInspections', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.QualityInspections');


        /*=====================================================================
          14. SupplierInvoices
          Dates remain NULL when missing/invalid. FKs are never replaced by 0.
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.SupplierInvoices
        (
            invoice_id,
            invoice_number,
            shipment_id,
            supplier_id,
            invoice_date,
            invoice_amount,
            tax_amount,
            total_amount,
            due_date,
            payment_terms,
            payment_status
        )
        SELECT
            invoice_id,
            COALESCE(NULLIF(UPPER(TRIM(invoice_number)), ''), 'UNKNOWN'),
            TRY_CONVERT(INT, shipment_id),
            TRY_CONVERT(INT, supplier_id),
            TRY_CONVERT(DATE, invoice_date),
            COALESCE(invoice_amount, 0),
            COALESCE(tax_amount, 0),
            COALESCE(total_amount, 0),
            TRY_CONVERT(DATE, due_date),
            COALESCE(NULLIF(TRIM(payment_terms), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(payment_status), ''), 'Unknown')
        FROM bronze.SupplierInvoices;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 14, 'silver.SupplierInvoices', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.SupplierInvoices');


        /*=====================================================================
          15. SupplierInvoiceDetails
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.SupplierInvoiceDetails
        (
            invoice_detail_id,
            invoice_id,
            gr_detail_id,
            billed_quantity,
            unit_price,
            tax_amount,
            line_amount
        )
        SELECT
            invoice_detail_id,
            invoice_id,
            gr_detail_id,
            COALESCE(TRY_CONVERT(INT, billed_quantity), 0),
            COALESCE(TRY_CONVERT(DECIMAL(18,3), unit_price), 0),
            COALESCE(TRY_CONVERT(DECIMAL(22,3), tax_amount), 0),
            COALESCE(TRY_CONVERT(DECIMAL(22,3), line_amount), 0)
        FROM bronze.SupplierInvoiceDetails;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 15, 'silver.SupplierInvoiceDetails', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.SupplierInvoiceDetails');


        /*=====================================================================
          16. SupplierPayments
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.SupplierPayments
        (
            payment_id,
            invoice_id,
            payment_date,
            payment_amount,
            payment_method,
            currency,
            transaction_reference,
            payment_status
        )
        SELECT
            payment_id,
            invoice_id,
            TRY_CONVERT(DATE, payment_date),
            COALESCE(TRY_CONVERT(DECIMAL(22,3), payment_amount), 0),
            COALESCE(NULLIF(TRIM(payment_method), ''), 'Unknown'),
            COALESCE(NULLIF(UPPER(TRIM(currency)), ''), 'Unknown'),
            COALESCE(NULLIF(UPPER(TRIM(transaction_reference)), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(payment_status), ''), 'Unknown')
        FROM bronze.SupplierPayments;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 16, 'silver.SupplierPayments', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.SupplierPayments');


        /*=====================================================================
          17. Warehouses
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.Warehouses
        (
            warehouse_id,
            warehouse_code,
            warehouse_name,
            warehouse_type,
            country,
            city,
            location_description,
            status
        )
        SELECT
            warehouse_id,
            COALESCE(NULLIF(UPPER(TRIM(warehouse_code)), ''), 'UNKNOWN'),
            COALESCE(NULLIF(TRIM(warehouse_name), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(warehouse_type), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(country), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(city), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(location_description), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(status), ''), 'Unknown')
        FROM bronze.Warehouses;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 17, 'silver.Warehouses', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.Warehouses');


        /*=====================================================================
          18. RawMaterialInventory
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.RawMaterialInventory
        (
            raw_inventory_id,
            warehouse_id,
            material_id,
            quantity_on_hand,
            quantity_reserved,
            reorder_point,
            safety_stock_level,
            max_inventory_level,
            unit_cost,
            last_updated_at
        )
        SELECT
            raw_inventory_id,
            warehouse_id,
            material_id,
            COALESCE(TRY_CONVERT(INT, quantity_on_hand), 0),
            COALESCE(TRY_CONVERT(INT, quantity_reserved), 0),
            COALESCE(TRY_CONVERT(INT, reorder_point), 0),
            COALESCE(TRY_CONVERT(INT, safety_stock_level), 0),
            COALESCE(TRY_CONVERT(INT, max_inventory_level), 0),
            COALESCE(TRY_CONVERT(DECIMAL(22,2), unit_cost), 0),
            TRY_CONVERT(DATETIME2(0), last_updated_at)
        FROM bronze.RawMaterialInventory;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 18, 'silver.RawMaterialInventory', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.RawMaterialInventory');


        /*=====================================================================
          19. Products
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.Products
        (
            product_id,
            product_code,
            product_name,
            product_category,
            uom,
            standard_cost,
            selling_price,
            status
        )
        SELECT
            product_id,
            COALESCE(NULLIF(UPPER(TRIM(product_code)), ''), 'UNKNOWN'),
            COALESCE(NULLIF(TRIM(product_name), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(product_category), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(uom), ''), 'Unknown'),
            TRY_CONVERT(DECIMAL(18,2), standard_cost),
            TRY_CONVERT(DECIMAL(18,2), selling_price),
            COALESCE(NULLIF(TRIM(status), ''), 'Unknown')
        FROM bronze.Products;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 19, 'silver.Products', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.Products');


        /*=====================================================================
          20. ProductBOM
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.ProductBOM
        (
            bom_id,
            product_id,
            material_id,
            quantity_required,
            uom,
            status
        )
        SELECT
            bom_id,
            product_id,
            material_id,
            TRY_CONVERT(DECIMAL(18,3), quantity_required),
            COALESCE(NULLIF(TRIM(uom), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(status), ''), 'Unknown')
        FROM bronze.ProductBOM;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 20, 'silver.ProductBOM', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.ProductBOM');


        /*=====================================================================
          21. Production
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.Production
        (
            production_id,
            production_order_code,
            product_id,
            planned_quantity,
            start_date,
            expected_end_date,
            actual_end_date,
            production_quantity,
            rejected_quantity,
            production_status
        )
        SELECT
            TRY_CONVERT(INT, production_id),
            COALESCE(NULLIF(UPPER(TRIM(production_order_code)), ''), 'UNKNOWN'),
            product_id,
            TRY_CONVERT(DECIMAL(18,2), planned_quantity),
            TRY_CONVERT(DATE, start_date),
            TRY_CONVERT(DATE, expected_end_date),
            TRY_CONVERT(DATE, actual_end_date),
            TRY_CONVERT(DECIMAL(18,2), production_quantity),
            TRY_CONVERT(DECIMAL(18,2), rejected_quantity),
            COALESCE(NULLIF(TRIM(production_status), ''), 'Unknown')
        FROM bronze.Production;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 21, 'silver.Production', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.Production');


        /*=====================================================================
          22. ProductionDetails
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.ProductionDetails
        (
            production_detail_id,
            production_id,
            bom_id,
            raw_inventory_id,
            actual_consumed_quantity,
            return_quantity,
            scrap_quantity,
            unit_cost,
            total_material_cost
        )
        SELECT
            production_detail_id,
            production_id,
            bom_id,
            raw_inventory_id,
            TRY_CONVERT(DECIMAL(18,3), actual_consumed_quantity),
            TRY_CONVERT(DECIMAL(18,3), return_quantity),
            TRY_CONVERT(DECIMAL(18,3), scrap_quantity),
            TRY_CONVERT(DECIMAL(18,2), unit_cost),
            ROUND(
                TRY_CONVERT(DECIMAL(18,3), actual_consumed_quantity)
                * TRY_CONVERT(DECIMAL(18,2), unit_cost),
                4
            )
        FROM bronze.ProductionDetails;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 22, 'silver.ProductionDetails', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.ProductionDetails');


        /*=====================================================================
          23. RawMaterialInventoryTransactions
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.RawMaterialInventoryTransactions
        (
            raw_transaction_id,
            raw_inventory_id,
            production_id,
            inspection_id,
            transaction_type,
            quantity,
            unit_cost,
            transaction_date,
            reference_code
        )
        SELECT
            raw_transaction_id,
            raw_inventory_id,
            production_id,
            inspection_id,
            COALESCE(NULLIF(TRIM(transaction_type), ''), 'Unknown'),
            TRY_CONVERT(DECIMAL(18,2), quantity),
            TRY_CONVERT(DECIMAL(18,2), unit_cost),
            TRY_CONVERT(DATETIME2(0), transaction_date),
            COALESCE(NULLIF(UPPER(TRIM(reference_code)), ''), 'Unknown')
        FROM bronze.RawMaterialInventoryTransactions;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 23, 'silver.RawMaterialInventoryTransactions', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.RawMaterialInventoryTransactions');


        /*=====================================================================
          24. FinishedGoodsInventory
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.FinishedGoodsInventory
        (
            finished_goods_inventory_id,
            warehouse_id,
            product_id,
            quantity_on_hand,
            quantity_reserved,
            reorder_point,
            safety_stock_level,
            last_updated_at
        )
        SELECT
            finished_goods_inventory_id,
            warehouse_id,
            product_id,
            COALESCE(TRY_CONVERT(INT, quantity_on_hand), 0),
            COALESCE(TRY_CONVERT(INT, quantity_reserved), 0),
            COALESCE(TRY_CONVERT(INT, reorder_point), 0),
            COALESCE(TRY_CONVERT(INT, safety_stock_level), 0),
            TRY_CONVERT(DATETIME2(0), last_updated_at)
        FROM bronze.FinishedGoodsInventory;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 24, 'silver.FinishedGoodsInventory', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.FinishedGoodsInventory');


        /*=====================================================================
          25. Customers
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.Customers
        (
            customer_id,
            customer_code,
            customer_name,
            customer_type,
            email,
            phone,
            country,
            city,
            address,
            registration_date,
            default_discount_percentage,
            status
        )
        SELECT
            customer_id,
            COALESCE(NULLIF(UPPER(TRIM(customer_code)), ''), 'UNKNOWN'),
            COALESCE(NULLIF(TRIM(customer_name), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(customer_type), ''), 'Unknown'),
            COALESCE(NULLIF(LOWER(TRIM(email)), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(phone), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(country), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(city), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(address), ''), 'Unknown'),
            TRY_CONVERT(DATE, registration_date),
            TRY_CONVERT(DECIMAL(18,2), default_discount_percentage),
            COALESCE(NULLIF(TRIM(status), ''), 'Unknown')
        FROM bronze.Customers;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 25, 'silver.Customers', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.Customers');


        /*=====================================================================
          26. SalesOrders
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.SalesOrders
        (
            sales_order_id,
            sales_order_code,
            customer_id,
            order_date,
            required_delivery_date,
            payment_method,
            tax_percentage,
            sales_order_status
        )
        SELECT
            sales_order_id,
            COALESCE(NULLIF(UPPER(TRIM(sales_order_code)), ''), 'UNKNOWN'),
            customer_id,
            TRY_CONVERT(DATE, order_date),
            TRY_CONVERT(DATE, required_delivery_date),
            COALESCE(NULLIF(TRIM(payment_method), ''), 'Unknown'),
            TRY_CONVERT(DECIMAL(18,2), tax_percentage),
            COALESCE(NULLIF(TRIM(sales_order_status), ''), 'Unknown')
        FROM bronze.SalesOrders;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 26, 'silver.SalesOrders', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.SalesOrders');


        /*=====================================================================
          27. SalesOrderDetails
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.SalesOrderDetails
        (
            sales_order_detail_id,
            sales_order_id,
            product_id,
            ordered_quantity,
            line_status
        )
        SELECT
            sales_order_detail_id,
            sales_order_id,
            product_id,
            TRY_CONVERT(INT, ordered_quantity),
            CASE
                WHEN LOWER(TRIM(line_status)) LIKE 'fulfilled%' THEN 'Fulfilled'
                WHEN LOWER(TRIM(line_status)) LIKE 'partially fulfilled%' THEN 'Partially Fulfilled'
                ELSE COALESCE(NULLIF(TRIM(line_status), ''), 'Unknown')
            END
        FROM bronze.SalesOrderDetails;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 27, 'silver.SalesOrderDetails', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.SalesOrderDetails');


        /*=====================================================================
          28. CustomerShipments
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.CustomerShipments
        (
            customer_shipment_id,
            shipment_code,
            sales_order_id,
            warehouse_id,
            shipment_date,
            expected_delivery_date,
            actual_delivery_date,
            tracking_number,
            shipping_method,
            shipping_cost,
            delivery_address,
            shipment_status,
            delivery_confirmation,
            customer_feedback
        )
        SELECT
            customer_shipment_id,
            COALESCE(NULLIF(UPPER(TRIM(shipment_code)), ''), 'UNKNOWN'),
            sales_order_id,
            warehouse_id,
            TRY_CONVERT(DATE, shipment_date),
            TRY_CONVERT(DATE, expected_delivery_date),
            TRY_CONVERT(DATE, actual_delivery_date),
            COALESCE(NULLIF(UPPER(TRIM(tracking_number)), ''), 'UNKNOWN'),
            CASE
                WHEN LOWER(TRIM(shipping_method)) = 'dedicated truck' THEN 'Dedicated Truck'
                WHEN LOWER(TRIM(shipping_method)) = 'domestic courier' THEN 'Domestic Courier'
                ELSE COALESCE(NULLIF(TRIM(shipping_method), ''), 'Unknown')
            END,
            COALESCE(shipping_cost, 0),
            COALESCE(NULLIF(TRIM(delivery_address), ''), 'Unknown'),
            CASE
                WHEN LOWER(TRIM(shipment_status)) = 'delivered' THEN 'Delivered'
                WHEN LOWER(TRIM(shipment_status)) = 'delivered late' THEN 'Delivered Late'
                ELSE COALESCE(NULLIF(TRIM(shipment_status), ''), 'Unknown')
            END,
            CASE WHEN delivery_confirmation = 1 THEN 1 ELSE 0 END,
            COALESCE(NULLIF(TRIM(customer_feedback), ''), 'Unknown')
        FROM bronze.CustomerShipments;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 28, 'silver.CustomerShipments', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.CustomerShipments');


        /*=====================================================================
          29. CustomerShipmentDetails
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.CustomerShipmentDetails
        (
            customer_shipment_detail_id,
            customer_shipment_id,
            sales_order_detail_id,
            shipped_quantity
        )
        SELECT
            customer_shipment_detail_id,
            customer_shipment_id,
            sales_order_detail_id,
            COALESCE(TRY_CONVERT(INT, shipped_quantity), 0)
        FROM bronze.CustomerShipmentDetails;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 29, 'silver.CustomerShipmentDetails', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.CustomerShipmentDetails');


        /*=====================================================================
          30. FinishedGoodsInventoryTransactions
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.FinishedGoodsInventoryTransactions
        (
            finished_inventory_transaction_id,
            finished_goods_inventory_id,
            production_id,
            customer_shipment_detail_id,
            transaction_type,
            quantity,
            unit_cost,
            transaction_date,
            reference_code
        )
        SELECT
            finished_inventory_transaction_id,
            finished_goods_inventory_id,
            production_id,
            customer_shipment_detail_id,
            COALESCE(NULLIF(TRIM(transaction_type), ''), 'Unknown'),
            COALESCE(TRY_CONVERT(INT, quantity), 0),
            COALESCE(TRY_CONVERT(DECIMAL(18,2), unit_cost), 0),
            TRY_CONVERT(DATETIME2(0), transaction_date),
            COALESCE(NULLIF(UPPER(TRIM(reference_code)), ''), 'Unknown')
        FROM bronze.FinishedGoodsInventoryTransactions;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 30, 'silver.FinishedGoodsInventoryTransactions', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.FinishedGoodsInventoryTransactions');


        /*=====================================================================
          31. Returns
          No WHERE filtering: all source rows are preserved.
        =====================================================================*/
        SET @TableStart = SYSDATETIME();

        INSERT INTO silver.Returns
        (
            return_id,
            return_code,
            customer_shipment_detail_id,
            return_request_date,
            return_received_date,
            returned_quantity,
            return_reason,
            product_condition,
            return_status
        )
        SELECT
            return_id,
            COALESCE(NULLIF(UPPER(TRIM(return_code)), ''), 'UNKNOWN'),
            customer_shipment_detail_id,
            TRY_CONVERT(DATE, return_request_date),
            TRY_CONVERT(DATE, return_received_date),
            TRY_CONVERT(DECIMAL(18,2), returned_quantity),
            COALESCE(NULLIF(TRIM(return_reason), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(product_condition), ''), 'Unknown'),
            COALESCE(NULLIF(TRIM(return_status), ''), 'Unknown')
        FROM bronze.Returns;

        SET @RowsLoaded = @@ROWCOUNT;
        INSERT INTO #ETL_Load_Log
        SELECT 31, 'silver.Returns', @RowsLoaded, COUNT(*),
               DATEDIFF_BIG(MILLISECOND, @TableStart, SYSDATETIME()), 'LOADED'
        FROM sys.columns
        WHERE object_id = OBJECT_ID('silver.Returns');

		/*=====================================================================
			COMMIT ONLY AFTER ALL TABLES LOAD SUCCESSFULLY
		=====================================================================*/

		COMMIT TRANSACTION;


		/*=====================================================================
			FINAL ETL LOAD SUMMARY
		=====================================================================*/

		SELECT
			load_order,
			table_name,
			rows_loaded,
			column_count,
			duration_ms,
			CAST(duration_ms / 1000.0 AS DECIMAL(18,3)) AS duration_seconds,
			load_status
		FROM #ETL_Load_Log
		ORDER BY load_order;


		SELECT
			COUNT(*) AS tables_loaded,
			SUM(rows_loaded) AS total_rows_loaded,
			SUM(column_count) AS total_columns_across_tables,
			DATEDIFF_BIG(
				MILLISECOND,
				@PipelineStart,
				SYSDATETIME()
			) AS total_pipeline_ms,

			CAST(
				DATEDIFF_BIG(
					MILLISECOND,
					@PipelineStart,
					SYSDATETIME()
				) / 1000.0
				AS DECIMAL(18,3)
			) AS total_pipeline_seconds,

			'SUCCESS' AS pipeline_status
		FROM #ETL_Load_Log;


		/*=====================================================================
			END TRY
		=====================================================================*/

		END TRY

		BEGIN CATCH

			IF @@TRANCOUNT > 0
				ROLLBACK TRANSACTION;

			SELECT
				ERROR_NUMBER() AS error_number,
				ERROR_LINE() AS error_line,
				ERROR_MESSAGE() AS error_message,
				DATEDIFF_BIG(
					MILLISECOND,
					@PipelineStart,
					SYSDATETIME()
				) AS elapsed_ms,
				'FAILED - TRANSACTION ROLLED BACK' AS pipeline_status;

			THROW;

		END CATCH;

		END;
		GO


		EXEC Refresh_Silver_Data;
		GO


	