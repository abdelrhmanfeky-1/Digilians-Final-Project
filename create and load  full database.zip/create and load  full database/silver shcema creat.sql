
/*=============================================================================
 2. DROP TABLES IN REVERSE DEPENDENCY ORDER
=============================================================================*/
DROP TABLE IF EXISTS silver.Returns;
DROP TABLE IF EXISTS silver.FinishedGoodsInventoryTransactions;
DROP TABLE IF EXISTS silver.CustomerShipmentDetails;
DROP TABLE IF EXISTS silver.CustomerShipments;
DROP TABLE IF EXISTS silver.SalesOrderDetails;
DROP TABLE IF EXISTS silver.SalesOrders;
DROP TABLE IF EXISTS silver.Customers;
DROP TABLE IF EXISTS silver.FinishedGoodsInventory;

DROP TABLE IF EXISTS silver.RawMaterialInventoryTransactions;
DROP TABLE IF EXISTS silver.ProductionDetails;
DROP TABLE IF EXISTS silver.Production;
DROP TABLE IF EXISTS silver.ProductBOM;
DROP TABLE IF EXISTS silver.Products;
DROP TABLE IF EXISTS silver.RawMaterialInventory;
DROP TABLE IF EXISTS silver.Warehouses;

DROP TABLE IF EXISTS silver.SupplierPayments;
DROP TABLE IF EXISTS silver.SupplierInvoiceDetails;
DROP TABLE IF EXISTS silver.SupplierInvoices;
DROP TABLE IF EXISTS silver.QualityInspections;
DROP TABLE IF EXISTS silver.GoodsReceiptDetails;
DROP TABLE IF EXISTS silver.GoodsReceipts;
DROP TABLE IF EXISTS silver.SupplierShipmentDetails;
DROP TABLE IF EXISTS silver.SupplierShipments;

DROP TABLE IF EXISTS silver.PurchaseOrderDetails;
DROP TABLE IF EXISTS silver.PurchaseOrders;
DROP TABLE IF EXISTS silver.PurchaseRequisitionDetails;
DROP TABLE IF EXISTS silver.PurchaseRequisitions;
DROP TABLE IF EXISTS silver.SupplierMaterials;
DROP TABLE IF EXISTS silver.Suppliers;
DROP TABLE IF EXISTS silver.Materials;
DROP TABLE IF EXISTS silver.Departments;
GO

/*=============================================================================
 3. PROCUREMENT & SOURCING
=============================================================================*/
CREATE TABLE silver.Departments
(
    department_id          INT          NOT NULL,

    department_code        VARCHAR(20)  NOT NULL,

    department_name        VARCHAR(100) NOT NULL,

    department_description VARCHAR(250) NOT NULL,

    status                 VARCHAR(20)  NOT NULL,

    CONSTRAINT PK_Departments PRIMARY KEY (department_id)
);
GO

CREATE TABLE silver.Materials
(
    material_id       INT           NOT NULL,

    material_code     VARCHAR(30)   NOT NULL,

    material_name     VARCHAR(100)  NOT NULL,

    material_category VARCHAR(60)   NOT NULL,

    material_type     VARCHAR(50)   NOT NULL,

    uom               VARCHAR(20)   NOT NULL,

    unit_weight       DECIMAL(18,3) NOT NULL,

    status            VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_Materials PRIMARY KEY (material_id)
);
GO

CREATE TABLE silver.Suppliers
(
    supplier_id       INT          NOT NULL,

    supplier_code     VARCHAR(30)  NOT NULL,

    supplier_name     VARCHAR(120) NOT NULL,

    supplier_type     VARCHAR(50)  NOT NULL,

    supplier_category VARCHAR(50)  NOT NULL,

    country           VARCHAR(50)  NOT NULL,

    city              VARCHAR(50)  NOT NULL,

    address           VARCHAR(250) NOT NULL,

    contact_person    VARCHAR(100) NOT NULL,

    phone             VARCHAR(20)  NOT NULL,

    email             VARCHAR(120) NOT NULL,

    payment_terms     VARCHAR(50)  NOT NULL,

    status            VARCHAR(20)  NOT NULL,

    CONSTRAINT PK_Suppliers PRIMARY KEY (supplier_id)
);
GO	

CREATE TABLE silver.SupplierMaterials
(
    supplier_material_id   INT           NOT NULL,

    supplier_id            INT           NOT NULL,

    material_id            INT           NOT NULL,

    supplier_material_code VARCHAR(50)   NOT NULL,

    standard_price         DECIMAL(18,2) NOT NULL,

    lead_time_days         INT           NOT NULL,

    minimum_order_quantity INT           NOT NULL,

    preferred_supplier     INT          NOT NULL,

    status                 VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_SupplierMaterials PRIMARY KEY (supplier_material_id),

    CONSTRAINT FK_SupplierMaterials_Suppliers
            FOREIGN KEY (supplier_id) REFERENCES silver.Suppliers(supplier_id),

    CONSTRAINT FK_SupplierMaterials_Materials
            FOREIGN KEY (material_id) REFERENCES silver.Materials(material_id)
);
GO

CREATE TABLE silver.PurchaseRequisitions
(
    pr_id            INT          NOT NULL,

    pr_code          VARCHAR(20)  NOT NULL,

    department_id    INT          NOT NULL,

    requested_by     VARCHAR(100) NOT NULL,

    request_date     DATE         NOT NULL,

    order_date       DATE         NULL,

    required_date    DATE     NOT NULL,

    priority         VARCHAR(20)  NOT NULL,

    approval_status  VARCHAR(20)  NOT NULL,

    approved_by      VARCHAR(100) NOT NULL,

    approval_date    DATE         NOT NULL,

    rejection_reason VARCHAR(250) NULL,

    created_date     DATETIME2 (0) NOT NULL,

    CONSTRAINT PK_PurchaseRequisitions PRIMARY KEY (pr_id),

    CONSTRAINT FK_PurchaseRequisitions_Departments
            FOREIGN KEY (department_id) REFERENCES silver.Departments(department_id)
);
GO

CREATE TABLE silver.PurchaseRequisitionDetails
(
    pr_detail_id        INT           NOT NULL,

    pr_id               INT           NOT NULL,

    material_id         INT           NOT NULL,

    requested_quantity  Int           NOT NULL,

    estimated_unit_cost INT           NOT NULL,

    CONSTRAINT PK_PurchaseRequisitionDetails PRIMARY KEY (pr_detail_id),

    CONSTRAINT FK_PRDetails_PR
            FOREIGN KEY (pr_id) REFERENCES silver.PurchaseRequisitions(pr_id),

    CONSTRAINT FK_PRDetails_Materials
            FOREIGN KEY (material_id) REFERENCES silver.Materials(material_id)
);
GO

CREATE TABLE silver.PurchaseOrders
(
    po_id                  INT          NOT NULL,

    po_code                VARCHAR(20)  NOT NULL,

    supplier_id            INT          NOT NULL,

    pr_id                  INT          NOT NULL,

    order_date             DATE         NOT NULL,

    expected_delivery_date DATE         NOT NULL,

    payment_terms          VARCHAR(50)  NOT NULL,

    status                 VARCHAR(20)  NOT NULL,

    CONSTRAINT PK_PurchaseOrders PRIMARY KEY (po_id),

    CONSTRAINT FK_PurchaseOrders_Suppliers
            FOREIGN KEY (supplier_id) REFERENCES silver.Suppliers(supplier_id),

    CONSTRAINT FK_PurchaseOrders_PR
            FOREIGN KEY (pr_id) REFERENCES silver.PurchaseRequisitions(pr_id)
);
GO

CREATE TABLE silver.PurchaseOrderDetails
(
    po_detail_id           INT           NOT NULL,

    po_id                  INT           NOT NULL,

    pr_detail_id           INT           NOT NULL,

    material_id            INT           NOT NULL,

    ordered_quantity       INT           NOT NULL,

    unit_price             DECIMAL(18,2) NOT NULL,

    discount_percentage    DECIMAL(5,2)  NOT NULL,

    expected_delivery_date DATE          NOT NULL,

    total_amount         DECIMAL(18,2)   NOT NULL,

    line_status            VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_PurchaseOrderDetails PRIMARY KEY (po_detail_id),

    CONSTRAINT FK_PODetails_PO
            FOREIGN KEY (po_id) REFERENCES silver.PurchaseOrders(po_id),

    CONSTRAINT FK_PODetails_PRDetails
            FOREIGN KEY (pr_detail_id) REFERENCES silver.PurchaseRequisitionDetails(pr_detail_id),

    CONSTRAINT FK_PODetails_Materials
            FOREIGN KEY (material_id) REFERENCES silver.Materials(material_id)
);
GO

/*=============================================================================
 4. INBOUND LOGISTICS, RECEIVING & ACCOUNTS PAYABLE
=============================================================================*/
CREATE TABLE silver.SupplierShipments
(
    shipment_id           INT           NOT NULL,

    shipment_code         VARCHAR(20)   NOT NULL,

    po_id                 INT           NOT NULL,

    supplier_id           INT           NOT NULL,

    supplier_reference    VARCHAR(50)   NOT NULL,

    ship_date             DATE          NOT NULL,

    expected_arrival_date DATE          NOT NULL,

    actual_arrival_date   DATE          NOT NULL,

    total_shipment_value  DECIMAL(18,2) NOT NULL,

    shipping_cost         DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_SupplierShipments PRIMARY KEY (shipment_id),

    CONSTRAINT FK_SupplierShipments_PO
            FOREIGN KEY (po_id) REFERENCES silver.PurchaseOrders(po_id),

    CONSTRAINT FK_SupplierShipments_Suppliers
            FOREIGN KEY (supplier_id) REFERENCES silver.Suppliers(supplier_id)
);
GO

CREATE TABLE silver.SupplierShipmentDetails
(
    shipment_detail_id INT           NOT NULL,

    shipment_id        INT           NOT NULL,

    po_detail_id       INT           NOT NULL,

    material_id        INT           NOT NULL,

    received_quantity  INT           NOT NULL,

    accepted_quantity  INT           NOT NULL,

    rejected_quantity  INT           NOT NULL,

    CONSTRAINT PK_SupplierShipmentDetails PRIMARY KEY (shipment_detail_id),

    CONSTRAINT FK_SupplierShipmentDetails_Shipments
            FOREIGN KEY (shipment_id) REFERENCES silver.SupplierShipments(shipment_id),

    CONSTRAINT FK_SupplierShipmentDetails_PODetails
            FOREIGN KEY (po_detail_id) REFERENCES silver.PurchaseOrderDetails(po_detail_id),

    CONSTRAINT FK_SupplierShipmentDetails_Materials
            FOREIGN KEY (material_id) REFERENCES silver.Materials(material_id)
);
GO

CREATE TABLE silver.GoodsReceipts
(
    gr_id                INT           NOT NULL,

    gr_code              VARCHAR(20)   NOT NULL,

    shipment_id          INT           NOT NULL,

    receipt_date         DATE          NOT NULL,

    received_by          VARCHAR(100)  NOT NULL,

    quality_check_status VARCHAR(20)   NOT NULL,

    total_received_value DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_GoodsReceipts PRIMARY KEY (gr_id),

    CONSTRAINT FK_GoodsReceipts_Shipments
            FOREIGN KEY (shipment_id) REFERENCES silver.SupplierShipments(shipment_id)
);
GO

CREATE TABLE silver.GoodsReceiptDetails
(
    gr_detail_id       INT           NOT NULL,

    gr_id              INT           NOT NULL,

    shipment_detail_id INT           NOT NULL,

    material_id        INT           NOT NULL,

    received_quantity  INT           NOT NULL,

    accepted_quantity  INT           NOT NULL,

    rejected_quantity  INT           NOT NULL,

    inspection_status  VARCHAR(30)   NOT NULL,

    batch_number       VARCHAR(50)   NOT NULL,

    CONSTRAINT PK_GoodsReceiptDetails PRIMARY KEY (gr_detail_id),

    CONSTRAINT FK_GoodsReceiptDetails_GR
            FOREIGN KEY (gr_id) REFERENCES silver.GoodsReceipts(gr_id),

    CONSTRAINT FK_GoodsReceiptDetails_ShipmentDetails
            FOREIGN KEY (shipment_detail_id)
            REFERENCES silver.SupplierShipmentDetails(shipment_detail_id),

    CONSTRAINT FK_GoodsReceiptDetails_Materials
            FOREIGN KEY (material_id) REFERENCES silver.Materials(material_id)
);
GO

CREATE TABLE silver.QualityInspections
(
    inspection_id         INT           NOT NULL,

    gr_detail_id          INT           NOT NULL,

    inspection_date       DATE          NOT NULL,

    inspection_type       VARCHAR(50)   NOT NULL,

    inspected_quantity    INT           NOT NULL,

    passed_quantity      INT            NOT NULL,

    inspection_result     VARCHAR(30)   NOT NULL,

    defect_quantity       INT           NOT NULL,

    defect_reason         VARCHAR(250)  NOT NULL,

    corrective_action     VARCHAR(250)  NOT NULL,

    reinspection_required BIT           NOT NULL,

    status                VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_QualityInspections PRIMARY KEY (inspection_id),

    CONSTRAINT FK_QualityInspections_GRDetails
            FOREIGN KEY (gr_detail_id) REFERENCES silver.GoodsReceiptDetails(gr_detail_id)
);
GO

CREATE TABLE silver.SupplierInvoices
(
    invoice_id     INT           NOT NULL,

    invoice_number VARCHAR(30)   NOT NULL,

    shipment_id    INT           NOT NULL,

    supplier_id    INT           NOT NULL,

    invoice_date   DATE          NOT NULL,

    invoice_amount DECIMAL(18,2) NOT NULL,

    tax_amount     DECIMAL(18,2) NOT NULL,

    total_amount   DECIMAL(18,2) NOT NULL,

    due_date       DATE          NOT NULL,

    payment_terms  VARCHAR(50)   NOT NULL,

    payment_status VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_SupplierInvoices PRIMARY KEY (invoice_id),

    CONSTRAINT FK_SupplierInvoices_Shipments
            FOREIGN KEY (shipment_id) REFERENCES silver.SupplierShipments(shipment_id),

    CONSTRAINT FK_SupplierInvoices_Suppliers
            FOREIGN KEY (supplier_id) REFERENCES silver.Suppliers(supplier_id)
);
GO

CREATE TABLE silver.SupplierInvoiceDetails
(
    invoice_detail_id INT           NOT NULL,

    invoice_id        INT           NOT NULL,

    gr_detail_id      INT           NOT NULL,

    billed_quantity   INT           NOT NULL,

    unit_price        DECIMAL(18,2) NOT NULL,

    tax_amount        DECIMAL(18,2) NOT NULL,

    line_amount       DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_SupplierInvoiceDetails PRIMARY KEY (invoice_detail_id),

    CONSTRAINT FK_SupplierInvoiceDetails_Invoices
            FOREIGN KEY (invoice_id) REFERENCES silver.SupplierInvoices(invoice_id),

    CONSTRAINT FK_SupplierInvoiceDetails_GRDetails
            FOREIGN KEY (gr_detail_id) REFERENCES silver.GoodsReceiptDetails(gr_detail_id)
);
GO

CREATE TABLE silver.SupplierPayments
(
    payment_id            INT           NOT NULL,

    invoice_id            INT           NOT NULL,

    payment_date          DATE          NOT NULL,

    payment_amount        DECIMAL(18,2) NOT NULL,

    payment_method        VARCHAR(30)   NOT NULL,

    currency              CHAR(3)       NOT NULL,

    transaction_reference VARCHAR(100)  NOT NULL,

    payment_status        VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_SupplierPayments PRIMARY KEY (payment_id),

    CONSTRAINT FK_SupplierPayments_Invoices
            FOREIGN KEY (invoice_id) REFERENCES silver.SupplierInvoices(invoice_id)
);
GO

/*=============================================================================
 5. WAREHOUSES & RAW MATERIAL INVENTORY
=============================================================================*/
CREATE TABLE silver.Warehouses
(
    warehouse_id         INT          NOT NULL,

    warehouse_code       VARCHAR(20)  NOT NULL,

    warehouse_name       VARCHAR(100) NOT NULL,

    warehouse_type       VARCHAR(50)  NOT NULL,

    country              VARCHAR(50)  NOT NULL,

    city                 VARCHAR(50)  NOT NULL,

    location_description VARCHAR(250) NOT NULL,

    status               VARCHAR(20)  NOT NULL,

    CONSTRAINT PK_Warehouses PRIMARY KEY (warehouse_id)
);
GO

CREATE TABLE silver.RawMaterialInventory
(
    raw_inventory_id    INT           NOT NULL,

    warehouse_id        INT           NOT NULL,

    material_id         INT           NOT NULL,

    quantity_on_hand   INT            NOT NULL,

    quantity_reserved   INT           NOT NULL,

    reorder_point       INT           NOT NULL,

    safety_stock_level  INT           NOT NULL,

    max_inventory_level INT            NOT NULL,

    unit_cost           DECIMAL(18,2) NOT NULL,

    last_updated_at     DATETIME2(0)  NOT NULL,

    CONSTRAINT PK_RawMaterialInventory PRIMARY KEY (raw_inventory_id),

    CONSTRAINT FK_RawInventory_Warehouses
            FOREIGN KEY (warehouse_id) REFERENCES silver.Warehouses(warehouse_id),

    CONSTRAINT FK_RawInventory_Materials
            FOREIGN KEY (material_id) REFERENCES silver.Materials(material_id)
);
GO

/*=============================================================================
 6. PRODUCTION / ASSEMBLY
=============================================================================*/
CREATE TABLE silver.Products
(
    product_id       INT           NOT NULL,

    product_code     VARCHAR(30)   NOT NULL,

    product_name     VARCHAR(100)  NOT NULL,

    product_category VARCHAR(50)   NOT NULL,

    uom              VARCHAR(20)   NOT NULL,

    standard_cost    DECIMAL(18,2) NOT NULL,

    selling_price    DECIMAL(18,2) NOT NULL,

    status           VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_Products PRIMARY KEY (product_id)
);
GO

CREATE TABLE silver.ProductBOM
(
    bom_id            INT           NOT NULL,

    product_id        INT           NOT NULL,

    material_id       INT           NOT NULL,

    quantity_required INT            NOT NULL,

    uom               VARCHAR(20)   NOT NULL,

    status            VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_ProductBOM PRIMARY KEY (bom_id),

    CONSTRAINT FK_ProductBOM_Products
            FOREIGN KEY (product_id) REFERENCES silver.Products(product_id),

    CONSTRAINT FK_ProductBOM_Materials
            FOREIGN KEY (material_id) REFERENCES silver.Materials(material_id)
);
GO

CREATE TABLE silver.Production
(
    production_id         INT           NOT NULL,

    production_order_code VARCHAR(30)   NOT NULL,

    product_id            INT           NOT NULL,

    planned_quantity      INT           NOT NULL,

    start_date            DATE          NOT NULL,

    expected_end_date     DATE          NOT NULL,

    actual_end_date       DATE          NOT NULL,

    production_quantity   INT            NOT NULL,

    rejected_quantity     INT           NOT NULL,

    production_status     VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_Production PRIMARY KEY (production_id),

    CONSTRAINT FK_Production_Products
            FOREIGN KEY (product_id) REFERENCES silver.Products(product_id)
);
GO

CREATE TABLE silver.ProductionDetails
(
    production_detail_id     INT           NOT NULL,

    production_id            INT           NOT NULL,

    bom_id                   INT           NOT NULL,

    raw_inventory_id         INT           NOT NULL,

    actual_consumed_quantity INT           NOT NULL,

    return_quantity          INT           NOT NULL,

    scrap_quantity           INT            NOT NULL,

    unit_cost                DECIMAL(18,2) NOT NULL,

    total_material_cost      DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_ProductionDetails PRIMARY KEY (production_detail_id),

    CONSTRAINT FK_ProductionDetails_Production
            FOREIGN KEY (production_id) REFERENCES silver.Production(production_id),

    CONSTRAINT FK_ProductionDetails_BOM
            FOREIGN KEY (bom_id) REFERENCES silver.ProductBOM(bom_id),

    CONSTRAINT FK_ProductionDetails_RawInventory
            FOREIGN KEY (raw_inventory_id) REFERENCES silver.RawMaterialInventory(raw_inventory_id)
);
GO

CREATE TABLE silver.RawMaterialInventoryTransactions
(
    raw_transaction_id INT           NOT NULL,

    raw_inventory_id   INT           NOT NULL,

    production_id      INT           NOT NULL,

    inspection_id      INT           NOT NULL,

    transaction_type   VARCHAR(40)   NOT NULL,

    quantity          INT            NOT NULL,

    unit_cost          DECIMAL(18,2) NOT NULL,

    transaction_date   DATETIME2(0)  NOT NULL,

    reference_code     VARCHAR(50)   NOT NULL,

    CONSTRAINT PK_RawMaterialInventoryTransactions PRIMARY KEY (raw_transaction_id),

    CONSTRAINT FK_RawTransactions_RawInventory
            FOREIGN KEY (raw_inventory_id) REFERENCES silver.RawMaterialInventory(raw_inventory_id),

    CONSTRAINT FK_RawTransactions_Production
            FOREIGN KEY (production_id) REFERENCES silver.Production(production_id),

    CONSTRAINT FK_RawTransactions_QualityInspection
            FOREIGN KEY (inspection_id) REFERENCES silver.QualityInspections(inspection_id)
);
GO

/*=============================================================================
 7. FINISHED GOODS, SALES & CUSTOMER SHIPMENTS
=============================================================================*/
CREATE TABLE silver.FinishedGoodsInventory
(
    finished_goods_inventory_id INT           NOT NULL,

    warehouse_id                INT           NOT NULL,

    product_id                  INT           NOT NULL,

    quantity_on_hand            INT           NOT NULL,

    quantity_reserved           INT           NOT NULL,

    reorder_point               INT           NOT NULL,

    safety_stock_level          INT           NOT NULL,

    last_updated_at             DATETIME2(0)  NOT NULL,

    CONSTRAINT PK_FinishedGoodsInventory PRIMARY KEY (finished_goods_inventory_id),

    CONSTRAINT FK_FGInventory_Warehouses
            FOREIGN KEY (warehouse_id) REFERENCES silver.Warehouses(warehouse_id),

    CONSTRAINT FK_FGInventory_Products
            FOREIGN KEY (product_id) REFERENCES silver.Products(product_id)
);
GO

CREATE TABLE silver.Customers
(
    customer_id                 INT           NOT NULL,

    customer_code               VARCHAR(30)   NOT NULL,

    customer_name               VARCHAR(100)  NOT NULL,

    customer_type               VARCHAR(50)   NOT NULL,

    email                       VARCHAR(120)  NULL,

    phone                       VARCHAR(20)   NOT NULL,

    country                     VARCHAR(50)   NOT NULL,

    city                        VARCHAR(50)   NOT NULL,

    address                     VARCHAR(250)  NOT NULL,

    registration_date           DATE          NOT NULL,

    default_discount_percentage DECIMAL(5,2)  NOT NULL,

    status                      VARCHAR(20)   NOT NULL,

    CONSTRAINT PK_Customers PRIMARY KEY (customer_id)
);
GO

CREATE TABLE silver.SalesOrders
(
    sales_order_id         INT           NOT NULL,

    sales_order_code       VARCHAR(20)   NOT NULL,

    customer_id            INT           NOT NULL,

    order_date             DATE          NOT NULL,

    required_delivery_date DATE          NOT NULL,

    payment_method         VARCHAR(30)   NOT NULL,

    tax_percentage         DECIMAL(5,2)  NOT NULL,

    sales_order_status     VARCHAR(30)   NOT NULL,

    CONSTRAINT PK_SalesOrders PRIMARY KEY (sales_order_id),

    CONSTRAINT FK_SalesOrders_Customers
            FOREIGN KEY (customer_id) REFERENCES silver.Customers(customer_id)
);
GO

CREATE TABLE silver.SalesOrderDetails
(
    sales_order_detail_id INT           NOT NULL,

    sales_order_id        INT           NOT NULL,

    product_id            INT           NOT NULL,

    ordered_quantity      INT           NOT NULL,

    line_status           VARCHAR(30)   NOT NULL,

    CONSTRAINT PK_SalesOrderDetails PRIMARY KEY (sales_order_detail_id),

    CONSTRAINT FK_SalesOrderDetails_Orders
            FOREIGN KEY (sales_order_id) REFERENCES silver.SalesOrders(sales_order_id),

    CONSTRAINT FK_SalesOrderDetails_Products
            FOREIGN KEY (product_id) REFERENCES silver.Products(product_id)
);
GO

CREATE TABLE silver.CustomerShipments
(
    customer_shipment_id   INT           NOT NULL,

    shipment_code          VARCHAR(20)   NOT NULL,

    sales_order_id         INT           NOT NULL,

    warehouse_id           INT           NOT NULL,

    shipment_date          DATE          NOT NULL,

    expected_delivery_date DATE          NOT NULL,

    actual_delivery_date   DATE          NULL,

    tracking_number        VARCHAR(50)   NOT NULL,

    shipping_method        VARCHAR(30)   NOT NULL,

    shipping_cost          DECIMAL(18,2) NOT NULL,

    delivery_address       VARCHAR(300)  NOT NULL,

    shipment_status        VARCHAR(30)   NOT NULL,

    delivery_confirmation  BIT           NOT NULL,

    customer_feedback      VARCHAR(500)  NOT NULL,

    CONSTRAINT PK_CustomerShipments PRIMARY KEY (customer_shipment_id),

    CONSTRAINT FK_CustomerShipments_SalesOrders
            FOREIGN KEY (sales_order_id) REFERENCES silver.SalesOrders(sales_order_id),

    CONSTRAINT FK_CustomerShipments_Warehouses
            FOREIGN KEY (warehouse_id) REFERENCES silver.Warehouses(warehouse_id)
);
GO

CREATE TABLE silver.CustomerShipmentDetails
(
    customer_shipment_detail_id INT           NOT NULL,

    customer_shipment_id        INT           NOT NULL,

    sales_order_detail_id       INT           NOT NULL,

    shipped_quantity            INT           NOT NULL,

    CONSTRAINT PK_CustomerShipmentDetails PRIMARY KEY (customer_shipment_detail_id),

    CONSTRAINT FK_CustomerShipmentDetails_Shipments
            FOREIGN KEY (customer_shipment_id) REFERENCES silver.CustomerShipments(customer_shipment_id),

    CONSTRAINT FK_CustomerShipmentDetails_SalesOrderDetails
            FOREIGN KEY (sales_order_detail_id) REFERENCES silver.SalesOrderDetails(sales_order_detail_id)
);
GO

CREATE TABLE silver.FinishedGoodsInventoryTransactions
(
    finished_inventory_transaction_id INT           NOT NULL,

    finished_goods_inventory_id       INT           NOT NULL,

    production_id                     INT           NOT NULL,

    customer_shipment_detail_id       INT           NOT NULL,

    transaction_type                  VARCHAR(40)   NOT NULL,

    quantity                         INT            NOT NULL,

    unit_cost                         DECIMAL(18,2) NOT NULL,

    transaction_date                  DATETIME2(0)  NOT NULL,

    reference_code                    VARCHAR(50)   NOT NULL,

    CONSTRAINT PK_FGInventoryTransactions PRIMARY KEY (finished_inventory_transaction_id),

    CONSTRAINT FK_FGTransactions_Inventory
            FOREIGN KEY (finished_goods_inventory_id) REFERENCES silver.FinishedGoodsInventory(finished_goods_inventory_id),

    CONSTRAINT FK_FGTransactions_Production
            FOREIGN KEY (production_id) REFERENCES silver.Production(production_id),

    CONSTRAINT FK_FGTransactions_CustomerShipmentDetails
            FOREIGN KEY (customer_shipment_detail_id)
            REFERENCES silver.CustomerShipmentDetails(customer_shipment_detail_id)
);
GO

/*=============================================================================
 8. RETURNS
=============================================================================*/
CREATE TABLE silver.Returns
(
    return_id                   INT           NOT NULL,

    return_code                 VARCHAR(20)   NOT NULL,

    customer_shipment_detail_id INT           NOT NULL,

    return_request_date         DATE          NOT NULL,

    return_received_date        DATE          NOT NULL,

    returned_quantity          INT            NOT NULL,

    return_reason               VARCHAR(120)  NOT NULL,

    product_condition           VARCHAR(50)   NOT NULL,

    return_status               VARCHAR(30)   NOT NULL,

    CONSTRAINT PK_Returns PRIMARY KEY (return_id),

    CONSTRAINT FK_Returns_CustomerShipmentDetails
            FOREIGN KEY (customer_shipment_detail_id)
            REFERENCES silver.CustomerShipmentDetails(customer_shipment_detail_id)
);
GO

/*=============================================================================
 9. INDEXES FOR FOREIGN KEYS AND ANALYTICS
=============================================================================*/
CREATE INDEX IX_SupplierMaterials_Supplier ON silver.SupplierMaterials(supplier_id);
CREATE INDEX IX_SupplierMaterials_Material ON silver.SupplierMaterials(material_id);
CREATE INDEX IX_PR_Department ON silver.PurchaseRequisitions(department_id);
CREATE INDEX IX_PR_ApprovalStatus ON silver.PurchaseRequisitions(approval_status);
CREATE INDEX IX_PRDetails_PR ON silver.PurchaseRequisitionDetails(pr_id);
CREATE INDEX IX_PO_Supplier ON silver.PurchaseOrders(supplier_id);
CREATE INDEX IX_PO_PR ON silver.PurchaseOrders(pr_id);
CREATE INDEX IX_PODetails_PO ON silver.PurchaseOrderDetails(po_id);

CREATE INDEX IX_SupplierShipments_PO ON silver.SupplierShipments(po_id);
CREATE INDEX IX_SupplierShipments_Supplier ON silver.SupplierShipments(supplier_id);
CREATE INDEX IX_SupplierShipments_Arrival ON silver.SupplierShipments(expected_arrival_date, actual_arrival_date);
CREATE INDEX IX_SupplierShipmentDetails_PO ON silver.SupplierShipmentDetails(po_detail_id);
CREATE INDEX IX_GoodsReceipts_Shipment ON silver.GoodsReceipts(shipment_id);
CREATE INDEX IX_GoodsReceiptDetails_Material ON silver.GoodsReceiptDetails(material_id);
CREATE INDEX IX_QualityInspections_GRDetail ON silver.QualityInspections(gr_detail_id);
CREATE INDEX IX_SupplierInvoices_Supplier ON silver.SupplierInvoices(supplier_id);
CREATE INDEX IX_SupplierPayments_Invoice ON silver.SupplierPayments(invoice_id);

CREATE INDEX IX_RawInventory_Material ON silver.RawMaterialInventory(material_id);
CREATE INDEX IX_RawInventory_Warehouse ON silver.RawMaterialInventory(warehouse_id);
CREATE INDEX IX_RawInventory_Reorder ON silver.RawMaterialInventory(reorder_point, quantity_on_hand);
CREATE INDEX IX_RawTransactions_Date ON silver.RawMaterialInventoryTransactions(transaction_date);
CREATE INDEX IX_RawTransactions_Inventory ON silver.RawMaterialInventoryTransactions(raw_inventory_id);

CREATE INDEX IX_ProductBOM_Product ON silver.ProductBOM(product_id);
CREATE INDEX IX_ProductBOM_Material ON silver.ProductBOM(material_id);
CREATE INDEX IX_Production_Product ON silver.Production(product_id);
CREATE INDEX IX_Production_Dates ON silver.Production(start_date, expected_end_date, actual_end_date);
CREATE INDEX IX_ProductionDetails_Production ON silver.ProductionDetails(production_id);

CREATE INDEX IX_FGInventory_Product ON silver.FinishedGoodsInventory(product_id);
CREATE INDEX IX_FGInventory_Warehouse ON silver.FinishedGoodsInventory(warehouse_id);
CREATE INDEX IX_Customers_City ON silver.Customers(city);
CREATE INDEX IX_Customers_Type ON silver.Customers(customer_type);
CREATE INDEX IX_Customers_Status ON silver.Customers(status);
CREATE INDEX IX_SalesOrders_Customer ON silver.SalesOrders(customer_id);
CREATE INDEX IX_SalesOrders_OrderDate ON silver.SalesOrders(order_date);
CREATE INDEX IX_SalesOrderDetails_Order ON silver.SalesOrderDetails(sales_order_id);
CREATE INDEX IX_SalesOrderDetails_Product ON silver.SalesOrderDetails(product_id);
CREATE INDEX IX_CustomerShipments_Order ON silver.CustomerShipments(sales_order_id);
CREATE INDEX IX_CustomerShipments_Status ON silver.CustomerShipments(shipment_status);
CREATE INDEX IX_CustomerShipments_DeliveryDates ON silver.CustomerShipments(expected_delivery_date, actual_delivery_date);
CREATE INDEX IX_CustomerShipmentDetails_Shipment ON silver.CustomerShipmentDetails(customer_shipment_id);
CREATE INDEX IX_FGTransactions_Inventory ON silver.FinishedGoodsInventoryTransactions(finished_goods_inventory_id);
CREATE INDEX IX_FGTransactions_Date ON silver.FinishedGoodsInventoryTransactions(transaction_date);
CREATE INDEX IX_Returns_ShipmentDetail ON silver.Returns(customer_shipment_detail_id);
CREATE INDEX IX_Returns_Condition ON silver.Returns(product_condition);
GO

/*=============================================================================
 10. RELATIONSHIP SUMMARY
=============================================================================
 Procurement
 -----------
 Departments 1 ---- * PurchaseRequisitions
 PurchaseRequisitions 1 ---- * PurchaseRequisitionDetails
 Suppliers * ---- * Materials through SupplierMaterials
 PurchaseRequisitions 1 ---- 0..1 PurchaseOrders
 Suppliers 1 ---- * PurchaseOrders
 PurchaseOrders 1 ---- * PurchaseOrderDetails
 PurchaseRequisitionDetails 1 ---- 0..1 PurchaseOrderDetails

 Inbound / Quality / Finance
 ---------------------------
 PurchaseOrders 1 ---- 1 SupplierShipments (current generated dataset)
 PurchaseOrderDetails 1 ---- 1 SupplierShipmentDetails (current generated dataset)
 SupplierShipments 1 ---- 1 GoodsReceipts
 SupplierShipmentDetails 1 ---- 1 GoodsReceiptDetails
 GoodsReceiptDetails 1 ---- 1 QualityInspections
 SupplierShipments 1 ---- 1 SupplierInvoices
 SupplierInvoices 1 ---- * SupplierInvoiceDetails
 SupplierInvoices 1 ---- * SupplierPayments

 Inventory / Production
 ----------------------
 Warehouses 1 ---- * RawMaterialInventory
 Materials 1 ---- * RawMaterialInventory
 Products * ---- * Materials through ProductBOM
 Products 1 ---- * Production
 Production 1 ---- * ProductionDetails
 RawMaterialInventory 1 ---- * ProductionDetails
 RawMaterialInventory 1 ---- * RawMaterialInventoryTransactions
 Production 1 ---- * RawMaterialInventoryTransactions
 QualityInspections 1 ---- * RawMaterialInventoryTransactions

 Sales / Delivery / Returns
 --------------------------
 Warehouses 1 ---- * FinishedGoodsInventory
 Products 1 ---- * FinishedGoodsInventory
 Customers 1 ---- * SalesOrders
 SalesOrders 1 ---- * SalesOrderDetails
 Products 1 ---- * SalesOrderDetails
 SalesOrders 1 ---- 1 CustomerShipments (current generated dataset)
 CustomerShipments 1 ---- * CustomerShipmentDetails
 SalesOrderDetails 1 ---- 1 CustomerShipmentDetails (current generated dataset)
 FinishedGoodsInventory 1 ---- * FinishedGoodsInventoryTransactions
 Production 1 ---- * FinishedGoodsInventoryTransactions
 CustomerShipmentDetails 1 ---- * FinishedGoodsInventoryTransactions
 CustomerShipmentDetails 1 ---- * Returns
=============================================================================*/

/*=============================================================================
 11. POST-CREATION CHECK
=============================================================================*/
DECLARE @BusinessTableCount INT =
(
    SELECT COUNT(*)
    FROM sys.tables t
    JOIN sys.schemas s ON s.schema_id = t.schema_id
    WHERE s.name = 'silver'
);

PRINT 'ElectronicsSupplyChainDB created successfully.';
PRINT 'Business tables created: ' + CAST(@BusinessTableCount AS VARCHAR(10));
PRINT 'Expected business tables: 31';
PRINT 'DDL is aligned with the FINAL 200,000-row CSV generator.';
GO
